import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { readFileSync } from "fs";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": "http://localhost:8000",
    },
    https: {
      key: readFileSync("./key.pem"),
      cert: readFileSync("./cert.pem"),
    },
  },
});
