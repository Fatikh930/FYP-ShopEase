/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          100: "#C8DFF5",
          200: "#C1DBF4",
          300: "#BAD7F2",
          400: "#A8C2DA",
          500: "#95ACC2",
        },
        secondary: "#061A40",
        gradient:
          "linear-gradient(180deg, rgba(186,215,242,1) 0%, rgba(255,255,255,1) 75%)",
      },
      fontFamily: {
        sans: ["Poppins", "sans-serif"],
        serif: ["Playfair Display", "serif"],
      },
      transitionProperty: {
        height: "height",
      },
    },
  },
  plugins: [
    require("@tailwindcss/aspect-ratio"),
    require("@tailwindcss/forms"),
  ],
};
