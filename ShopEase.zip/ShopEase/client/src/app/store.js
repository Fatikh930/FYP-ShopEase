import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "../features/Cart/CartSlice";
import categoryReducer from "../features/Category/CategorySlice";
import authReducer from "../features/Auth/AuthSlice";
import adminAuthReducer from "../features/Auth/AdminAuthSlice";

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    category: categoryReducer,
    auth: authReducer,
    adminAuth: adminAuthReducer,
  },
});
