import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { Header, Footer } from "../components";

const AuthLayoutUser = () => {
  const { pathname } = useLocation();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const isLoading = useSelector((state) => state.auth.isLoading);

  // If the user is not authenticated and not on the login or signup page,
  // redirect to the login page
  if (
    !isAuthenticated &&
    !isLoading &&
    pathname !== "/login" &&
    pathname !== "/signup"
  ) {
    return <Navigate to="/login" replace />;
  }

  // If the user is authenticated and on the login or signup page,
  // redirect to the home page
  if (isAuthenticated && (pathname === "/login" || pathname === "/signup")) {
    return <Navigate to="/" replace />;
  }

  // If the authentication status is still loading, render a loading indicator
  if (isLoading) {
    return <div>Loading...</div>;
  }

  // If the user is authenticated, render the protected route
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  );
};

export default AuthLayoutUser;
