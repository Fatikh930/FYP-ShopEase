import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import useAuthAdmin from "../Hooks/AdminAuthHook";

const AuthLayoutAdmin = () => {
  const { isAuthenticated, admin, isLoading } = useAuthAdmin();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!isAuthenticated || !admin || admin.role !== "admin") {
    return <Navigate to="/admin/login" replace />;
  }

  return (
    <>
      <AdminHeader />
      <Outlet />
    </>
  );
};

export default AuthLayoutAdmin;
