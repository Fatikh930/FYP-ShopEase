import logo_primary from "./logo_primary.svg";
import logo_secondary from "./logo_secondary.svg";
import nike from "./nike.svg";
import adidas from "./adidas.svg";
import puma from "./puma.svg";
import armour from "./armour.svg";
import gucci from "./gucci.svg";

export { logo_primary, logo_secondary, nike, adidas, puma, armour, gucci };
