import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const useAuthAdmin = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [admin, setAdmin] = useState(null);
  const navigate = useNavigate();

  const checkAuthentication = async () => {
    try {
      const response = await axios.post("/api/admins/check-auth");
      if (response.status === 200) {
        setAdmin(response.data.admin);
        setIsAuthenticated(true);
        console.log("admin data", response.data.admin);
      }
    } catch (error) {
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const logoutAdmin = async () => {
    try {
      const response = await axios.post("/api/admins/logout", null, {
        withCredentials: true,
      });
      if (response.status === 200) {
        setIsAuthenticated(false);
        console.log("Logout successful");
        navigate("/admin/login"); // Redirect to home page after logout
      } else {
        console.error("Logout failed");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  useEffect(() => {
    checkAuthentication();
  }, []);

  return { isAuthenticated, isLoading, admin, logoutAdmin };
};

export default useAuthAdmin;
