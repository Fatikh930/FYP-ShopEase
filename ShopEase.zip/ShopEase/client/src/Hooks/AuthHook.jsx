import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const checkAuthentication = async () => {
    try {
      const response = await axios.post("/api/users/check-auth");
      if (response.status === 200) {
        setUser(response.data.message);
        setIsAuthenticated(true);
        console.log("user data", response.data.message);
      }
    } catch (error) {
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const logoutUser = async () => {
    try {
      const response = await axios.post("/api/users/logout", null, {
        withCredentials: true,
      });
      if (response.status === 200) {
        setIsAuthenticated(false);
        console.log("Logout successful");
        navigate("/"); // Redirect to home page after logout
      } else {
        console.error("Logout failed");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  useEffect(() => {
    checkAuthentication();
  }, []);

  return { isAuthenticated, isLoading, user, logoutUser };
};

export default useAuth;
