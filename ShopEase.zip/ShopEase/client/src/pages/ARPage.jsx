import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import {
  bootstrapCameraKit,
  createMediaStreamSource,
  Transform2D,
} from "@snap/camera-kit";
import axios from "axios";

const ARPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState();
  const canvasRef = useRef(null);
  console.log("id", id);

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/api/products/get-product/${id}`
        );
        setProduct(response.data.product);
        console.log(
          "Product data inside fetchProductDetails:",
          response.data.product
        );
        initializeCamera(response.data.product);
      } catch (error) {
        console.error("Error fetching product details:", error);
      }
    };

    fetchProductDetails();
  }, [id]);

  console.log("product data", product);
  useEffect(() => {
    if (product) {
      console.log("Product data in useEffect:", product);
    }
  }, [product]);

  const initializeCamera = async (product) => {
    console.log("product data again", product);
    console.log("product data lens no", product.lensNo);
    const cameraKit = await bootstrapCameraKit({
      apiToken:
        "eyJhbGciOiJIUzI1NiIsImtpZCI6IkNhbnZhc1MyU0hNQUNQcm9kIiwidHlwIjoiSldUIn0.eyJhdWQiOiJjYW52YXMtY2FudmFzYXBpIiwiaXNzIjoiY2FudmFzLXMyc3Rva2VuIiwibmJmIjoxNzEzMTY1Mzc4LCJzdWIiOiJiZTQ4ZGQwNy1hYjZkLTQ2ZjItOTZhYy05YWFmM2RkNTBkNGF-U1RBR0lOR34yNjc3MWNmYy01YmZlLTQzYTEtOTZkYS1jMjU3YjEwZjJhYTAifQ.lx9VjAxI8EVBPfj3LBS6euMs2BFOu0t1EnfGy9q7OUc",
    });

    // Create session
    const session = await cameraKit.createSession();

    // Replace canvas element with live output
    const canvasElement = canvasRef.current;
    const liveOutput = session.output.live;
    canvasElement.replaceWith(liveOutput);

    // Load lenses
    const { lenses } = await cameraKit.lensRepository.loadLensGroups([
      product.lensGroupId,
    ]);

    // Apply lens
    await session.applyLens(lenses[product.lensNo]);

    // Get media stream
    let source = "";
    if (product.cameraType === "front") {
      let mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
      });

      // Create media stream source
      source = createMediaStreamSource(mediaStream, {
        transform: Transform2D.MirrorX,
        cameraType: "front",
      });
    } else {
      let mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
        },
      });
      source = createMediaStreamSource(mediaStream, {
        transform: Transform2D.MirrorX,
        cameraType: "back",
      });
    }

    // Set source
    await session.setSource(source);

    // Set render size
    session.source.setRenderSize(window.innerWidth, window.innerHeight);

    // Start session
    session.play();
  };

  return (
    <div>
      <canvas id="canvas" ref={canvasRef}></canvas>
    </div>
  );
};

export default ARPage;
