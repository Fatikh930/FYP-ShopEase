import React from "react";
import { ContactForm, FAQSection, GetInTouch } from "../components";

const Contact = () => {
  return (
    <>
      <ContactForm />
      <GetInTouch />
      <FAQSection />
    </>
  );
};

export default Contact;
