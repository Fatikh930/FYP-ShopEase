// import React, { useState } from "react";
// import axios from "axios";

// const CreateProduct = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     description: "",
//     price: "",
//     type: "",
//     cameraType: "",
//     lensGroupId: "",
//     lensNo: "",
//     lensId: "",
//     category: "",
//     productImage: null,
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleImageChange = (e) => {
//     setFormData({ ...formData, productImage: e.target.files[0] });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       const formDataForUpload = new FormData();
//       for (const key in formData) {
//         formDataForUpload.append(key, formData[key]);
//       }

//       const response = await axios.post(
//         "http://localhost:8000/api/products/create-product",
//         formDataForUpload,
//         {
//           headers: {
//             "Content-Type": "multipart/form-data",
//           },
//         }
//       );

//       console.log(response.data);
//     } catch (error) {
//       console.error(error.response.data.message);
//     }
//   };

//   return (
//     <div>
//       <h2>Create Product</h2>
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>Name:</label>
//           <input
//             type="text"
//             name="name"
//             value={formData.name}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Description:</label>
//           <input
//             type="text"
//             name="description"
//             value={formData.description}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Price:</label>
//           <input
//             type="number"
//             name="price"
//             value={formData.price}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Type:</label>
//           <select name="type" onChange={handleChange} value={formData.type}>
//             <option value="men">Men</option>
//             <option value="women">Women</option>
//           </select>
//         </div>
//         <div>
//           <label>Camera Type:</label>
//           <select
//             name="cameraType"
//             onChange={handleChange}
//             value={formData.cameraType}
//           >
//             <option value="front">Front</option>
//             <option value="back">Back</option>
//           </select>
//         </div>
//         <div>
//           <label>Lens Group ID:</label>
//           <input
//             type="text"
//             name="lensGroupId"
//             value={formData.lensGroupId}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Lens No:</label>
//           <input
//             type="number"
//             name="lensNo"
//             value={formData.lensNo}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Lens ID:</label>
//           <input
//             type="text"
//             name="lensId"
//             value={formData.lensId}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Category:</label>
//           <input
//             type="text"
//             name="category"
//             value={formData.category}
//             onChange={handleChange}
//           />
//         </div>
//         <div>
//           <label>Product Image:</label>
//           <input type="file" name="productImage" onChange={handleImageChange} />
//         </div>
//         <button type="submit">Create Product</button>
//       </form>
//     </div>
//   );
// };

// export default CreateProduct;

import React, { useState } from "react";
import axios from "axios";

const CreateProduct = () => {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    type: "",
    cameraType: "",
    lensGroupId: "",
    lensNo: "",
    lensId: "",
    category: "",
    productImage: null,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setFormData({ ...formData, productImage: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formDataForUpload = new FormData();
      for (const key in formData) {
        formDataForUpload.append(key, formData[key]);
      }

      const response = await axios.post(
        "http://localhost:8000/api/products/create-product",
        formDataForUpload,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log(response.data);
    } catch (error) {
      console.error(error.response.data.message);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-bold mb-4">Create Product</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Name:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Description:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Price:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Type:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="type"
            value={formData.type}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Camera Type:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="cameraType"
            value={formData.cameraType}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Lens Group ID:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="lensGroupId"
            value={formData.lensGroupId}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Lens No:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="number"
            name="lensNo"
            value={formData.lensNo}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Lens ID:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="lensId"
            value={formData.lensId}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Category:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Product Image:</label>
          <input
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-400"
            type="file"
            name="productImage"
            onChange={handleImageChange}
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-400 text-white py-2 px-4 rounded-md hover:bg-blue-500 transition duration-300"
        >
          Create Product
        </button>
      </form>
    </div>
  );
};

export default CreateProduct;
