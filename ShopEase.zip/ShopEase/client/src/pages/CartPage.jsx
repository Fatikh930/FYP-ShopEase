import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { CartItem, FormatPrice } from "../components";
import { useSelector } from "react-redux";
import axios from "axios";
import { loadStripe } from "@stripe/stripe-js";
import useAuth from "../Hooks/AuthHook";

const CartPage = () => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [shippingData, setShippingData] = useState({
    address: "",
    city: "",
    country: "",
    postalCode: "",
  });
  const [error, setError] = useState("");
  const { isAuthenticated } = useAuth();

  const handleInputChange = (e) => {
    setShippingData({
      ...shippingData,
      [e.target.name]: e.target.value,
    });
  };

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get("/api/users/get-cart-items", {
          withCredentials: true,
          responseType: "json",
        });
        setCartItems(response.data.cart);
        console.log("Cart items:", response.data.cart);
      } catch (error) {
        console.error(error);
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };

    fetchCartItems();
  }, []);

  const cartItemsWithProductData = cartItems.map((item) => {
    const { product, quantity } = item;
    product.quantity = quantity;
    return { product };
  });

  console.log("Cart items with product data:", cartItemsWithProductData);

  const product = cartItemsWithProductData.map((item) => item.product);

  console.log("Product:", product);

  const quantityOfProduct = cartItems.map((item) => {
    const { quantity } = item;
    return { quantity };
  });

  const quantity = quantityOfProduct.map((item) => item.quantity);

  console.log("Quantity:", quantity);

  console.log("Cart items with product data:", cartItemsWithProductData);

  const makePayment = async () => {
    if (
      !shippingData.address ||
      !shippingData.city ||
      !shippingData.country ||
      !shippingData.postalCode
    ) {
      setError("Please enter all the shipping details");
      return;
    }
    try {
      const stripe = await loadStripe(
        "pk_test_51PFqsjP1EqSrCbQojU5wCIXKgzlvIEfoAP9Dc4qGPiR7N9P4TnYfNjDHfYq3JwbJHmSnID51HFy6l7ja9XInYC0i00D07BAvJE"
      );

      const body = {
        product,
        shippingData,
      };

      const headers = {
        "Content-Type": "application/json",
      };

      const response = await axios.post(
        "/api/orders/create-checkout-session",
        body,
        { headers }
      );

      const session = response.data;

      const result = await stripe.redirectToCheckout({
        sessionId: session.id,
      });

      if (result.error) {
        console.error(result.error);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="bg-white">
          <div className="mx-auto max-w-2xl px-4 pb-24 pt-16 sm:px-6 lg:max-w-7xl lg:px-8">
            <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Shopping Cart
            </h1>
            <form className="mt-12 lg:grid lg:grid-cols-12 lg:items-start lg:gap-x-12 xl:gap-x-16">
              <section aria-labelledby="cart-heading" className="col-span-7">
                <ul role="list" className="divide-y divide-gray-200">
                  {cartItemsWithProductData.map((item) => (
                    <CartItem key={item.product._id} item={item} />
                  ))}
                </ul>
              </section>

              <section
                aria-labelledby="summary-heading"
                className="mt-16 rounded-lg bg-gray-50 px-4 py-6 sm:p-6 lg:col-span-5 lg:mt-0 lg:p-8"
              >
                <h2
                  id="summary-heading"
                  className="text-lg font-medium text-gray-900"
                >
                  Add Information
                </h2>

                <form onSubmit={(e) => e.preventDefault()}>
                  <div className="mt-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <dt className="text-sm text-gray-600">Address</dt>
                      <dd>
                        <input
                          type="text"
                          name="address"
                          value={shippingData.address}
                          onChange={handleInputChange}
                          className="text-sm font-medium text-gray-900"
                          required
                        />
                      </dd>
                    </div>
                    <div className="flex items-center justify-between">
                      <dt className="text-sm text-gray-600">City</dt>
                      <dd>
                        <input
                          type="text"
                          name="city"
                          value={shippingData.city}
                          onChange={handleInputChange}
                          className="text-sm font-medium text-gray-900"
                          required
                        />
                      </dd>
                    </div>
                    <div className="flex items-center justify-between">
                      <dt className="text-sm text-gray-600">Country</dt>
                      <dd>
                        <input
                          type="text"
                          name="country"
                          value={shippingData.country}
                          onChange={handleInputChange}
                          className="text-sm font-medium text-gray-900"
                          required
                        />
                      </dd>
                    </div>
                    <div className="flex items-center justify-between">
                      <dt className="text-sm text-gray-600">Postal Code</dt>
                      <dd>
                        <input
                          type="text"
                          name="postalCode"
                          value={shippingData.postalCode}
                          onChange={handleInputChange}
                          className="text-sm font-medium text-gray-900"
                          required
                        />
                      </dd>
                    </div>
                  </div>
                  <div className="mt-6">
                    {error && <p className="text-red-500">{error}</p>}
                    <button
                      type="button"
                      className="w-full rounded-md border border-transparent bg-blue-500 px-4 py-3 text-base font-medium text-white shadow-sm hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-gray-50"
                      onClick={makePayment}
                    >
                      Checkout
                    </button>
                  </div>
                </form>
              </section>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default CartPage;
