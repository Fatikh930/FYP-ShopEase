import React from "react";
import { Link } from "react-router-dom";
import { logo_primary } from "../assets";
import {
  HomeIcon,
  InboxIcon,
  ShoppingCartIcon,
} from "@heroicons/react/24/solid";

const ErrorPage = () => {
  return (
    <div className="bg-white">
      <main className="mx-auto w-full max-w-7xl px-6 pb-16 pt-10 sm:pb-24 lg:px-8">
        <img
          className="mx-auto h-10 w-auto sm:h-12"
          src={logo_primary}
          alt="Company Logo"
        />
        <div className="mx-auto mt-20 max-w-2xl text-center sm:mt-24">
          <p className="text-base font-semibold leading-8 text-blue-500">404</p>
          <h1 className="mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-5xl">
            This page does not exist
          </h1>
          <p className="mt-4 text-base leading-7 text-gray-600 sm:mt-6 sm:text-lg sm:leading-8">
            Sorry, we couldn’t find the page you’re looking for.
          </p>
        </div>
        <div className="mx-auto mt-16 flow-root max-w-lg sm:mt-20">
          <ul
            role="list"
            className="-m-6 divide-y-[1px] divide-gray-900/5 border-b border-gray-900/5"
          >
            <li className="relative flex gap-x-6 py-6">
              <div className="flex h-10 w-10 flex-none items-center justify-center rounded-lg shadow-sm ring-1 ring-gray-900/10">
                <HomeIcon className="h-6 w-6 text-blue-500" />
              </div>
              <div className="flex-auto">
                <h3 className="text-sm font-semibold leading-6 text-gray-900">
                  <Link to="/">
                    <span
                      className="absolute inset-0"
                      aria-hidden="true"
                    ></span>
                    Home
                  </Link>
                </h3>
                <p className="mt-2 text-sm leading-6 text-gray-600">
                  Go to home
                </p>
              </div>
              <div className="flex-none self-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                  className="h-5 w-5 text-gray-400"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z"
                    clipRule="evenodd"
                  ></path>
                </svg>
              </div>
            </li>
            <li className="relative flex gap-x-6 py-6">
              <div className="flex h-10 w-10 flex-none items-center justify-center rounded-lg shadow-sm ring-1 ring-gray-900/10">
                <InboxIcon className="h-6 w-6 text-blue-500" />
              </div>
              <div className="flex-auto">
                <h3 className="text-sm font-semibold leading-6 text-gray-900">
                  <Link to="/contact">
                    <span
                      className="absolute inset-0"
                      aria-hidden="true"
                    ></span>
                    Contact us
                  </Link>
                </h3>
                <p className="mt-2 text-sm leading-6 text-gray-600">
                  React out to us for any help
                </p>
              </div>
              <div className="flex-none self-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                  className="h-5 w-5 text-gray-400"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z"
                    clipRule="evenodd"
                  ></path>
                </svg>
              </div>
            </li>
            <li className="relative flex gap-x-6 py-6">
              <div className="flex h-10 w-10 flex-none items-center justify-center rounded-lg shadow-sm ring-1 ring-gray-900/10">
                <ShoppingCartIcon className="h-6 w-6 text-blue-500" />
              </div>
              <div className="flex-auto">
                <h3 className="text-sm font-semibold leading-6 text-gray-900">
                  <Link to="/products">
                    <span
                      className="absolute inset-0"
                      aria-hidden="true"
                    ></span>
                    Products
                  </Link>
                </h3>
                <p className="mt-2 text-sm leading-6 text-gray-600">
                  Explore our products
                </p>
              </div>
              <div className="flex-none self-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                  className="h-5 w-5 text-gray-400"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z"
                    clipRule="evenodd"
                  ></path>
                </svg>
              </div>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
};

export default ErrorPage;
