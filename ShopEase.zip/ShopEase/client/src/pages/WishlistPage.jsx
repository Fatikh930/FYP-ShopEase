import React, { useEffect, useState } from "react";
import axios from "axios";
import { WishlistItemCard } from "../components";

const WishlistPage = () => {
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchWishlist = async () => {
      try {
        const response = await axios.get("/api/users/get-wishlist");
        setWishlist(response.data.wishlist);
      } catch (err) {
        setError("Failed to fetch wishlist items");
      } finally {
        setLoading(false);
      }
    };

    fetchWishlist();
  }, []);

  const handleRemoveItem = (productId) => {
    setWishlist((prevWishlist) =>
      prevWishlist.filter((item) => item.product._id !== productId)
    );
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  const handleAddToCart = async (productId) => {
    try {
      const response = await axios.post("/api/users/add-to-cart", {
        productId,
      });
      console.log(response.data.message);
    } catch (error) {
      console.error("Error adding product to cart:", error);
    }
  };

  return (
    <div className="wishlist-page p-6 bg-white shadow-md rounded-lg">
      <h1 className="m-20 text-2xl font-bold mb-4">Your Wishlist</h1>
      <div className="max-w-3xl mx-auto">
        <ul className="divide-y divide-gray-200">
          {wishlist.map((item) => (
            <WishlistItemCard
              key={item.product._id}
              item={item}
              onRemove={handleRemoveItem}
              onAddToCart={handleAddToCart}
            />
          ))}
        </ul>
      </div>
    </div>
  );
};

export default WishlistPage;
