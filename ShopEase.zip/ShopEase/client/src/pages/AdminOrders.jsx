import React, { useEffect, useState } from "react";
import { AdminHeader, OrderCard } from "../components";
import axios from "axios";

const AdminOrders = () => {
  const text = "Orders";
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get("/api/orders/get-orders");
        setOrders(response.data);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  return (
    <>
      <AdminHeader text="Orders" />
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="m-20 grid grid-cols-3 gap-20">
          {orders.map((order) => (
            <OrderCard key={order._id} order={order} />
          ))}
        </div>
      )}
    </>
  );
};

export default AdminOrders;
