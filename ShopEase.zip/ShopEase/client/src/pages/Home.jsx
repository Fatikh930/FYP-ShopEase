import {
  HeroSection,
  LogoClouds,
  Testimonial,
  FeatureProducts,
  FAQSection,
  CollectionSection,
  Incentive,
} from "../components";

const Home = () => {
  return (
    <>
      <HeroSection />
      <CollectionSection />
      <FeatureProducts />
      <LogoClouds />
      <Testimonial />
      <FAQSection />
      <Incentive />
    </>
  );
};

export default Home;
