import React, { useState, useEffect } from "react";
import { AdminHeader, AdminCard } from "../components";
import axios from "axios";

const AdminTeam = () => {
  const text = "Team";
  const [admins, setAdmins] = useState([]);

  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8000/api/admins/get-all-admins"
        );
        setAdmins(response.data.admins);
        console.log(admins);
      } catch (error) {
        console.error("Error fetching admins:", error);
      }
    };

    fetchAdmins();
  }, []);

  return (
    <>
      <AdminHeader text={text} />
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4 lg:gap-12 lg:m-20 justify-items-center">
        {admins.map((admin) => (
          <AdminCard key={admin._id} admin={admin} />
        ))}
      </div>
    </>
  );
};

export default AdminTeam;
