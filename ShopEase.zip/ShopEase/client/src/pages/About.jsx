import React from "react";
import { Link } from "react-router-dom";
import {
  HeroSection,
  Incentive,
  LogoClouds,
  OurMissionSection,
  OurValuesSection,
} from "../components";

const About = () => {
  return (
    <>
      <HeroSection />
      <OurMissionSection />
      <OurValuesSection />
      <LogoClouds />
      <Incentive />
    </>
  );
};

export default About;
