import About from "./About";
import Contact from "./Contact";
import Home from "./Home";
import Products from "./Products";
import ErrorPage from "./ErrorPage";
import LoginPage from "./LoginPage";
import SignupPage from "./SignupPage";
import CartPage from "./CartPage";
import SingleProduct from "./SingleProduct";
import Checkout from "./Checkout";
import ARPage from "./ARPage";
import CreateProduct from "./CreateProduct";
import GetProducts from "./GetProducts";
import ProductDetails from "./ProductDetails";
import AdminOrders from "./AdminOrders";
import AdminCustomer from "./AdminCustomer";
import AdminProducts from "./AdminProducts";
import AdminTeam from "./AdminTeam";
import Success from "./Success";
import Cancelled from "./Cancelled";
import UserProfile from "./UserProfile";
import UpdateUserProfile from "./UpdateUserProfile";
import AdminLogin from "./AdminLogin";
import WishlistPage from "./WishlistPage";

export {
  About,
  Contact,
  Home,
  Products,
  ErrorPage,
  LoginPage,
  SignupPage,
  CartPage,
  SingleProduct,
  Checkout,
  ARPage,
  CreateProduct,
  GetProducts,
  ProductDetails,
  AdminOrders,
  AdminCustomer,
  AdminProducts,
  AdminTeam,
  Success,
  Cancelled,
  UserProfile,
  UpdateUserProfile,
  AdminLogin,
  WishlistPage,
};
