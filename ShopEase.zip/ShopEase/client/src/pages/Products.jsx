import React, { useState, useEffect } from "react";
import { CategoryFilters } from "../components";
import { useSelector } from "react-redux";
import axios from "axios";

const Products = () => {
  const category = useSelector((state) => state.category);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8000/api/products/get-products"
        );
        setProducts(response.data.products);
        setLoading(false);
        console.log("this is product", response.data.products);
      } catch (error) {
        console.error(error);
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <CategoryFilters category={category} products={products} />
      )}
    </>
  );
};

export default Products;
