import React from "react";

const Cancelled = () => {
  return <div>Cancelled</div>;
};

export default Cancelled;
