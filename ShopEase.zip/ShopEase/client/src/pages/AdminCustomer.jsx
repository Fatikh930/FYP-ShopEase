import React, { useEffect, useState } from "react";
import { AdminHeader, AdminCard } from "../components";
import axios from "axios";

const AdminCustomer = () => {
  const text = "Customers";
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8000/api/users/get-all-users"
        );
        setUsers(response.data.users);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <>
      <AdminHeader text={text} />
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4 lg:gap-12 lg:m-20 justify-items-center">
        {users.map((user) => (
          <AdminCard key={user._id} admin={user} />
        ))}
      </div>
    </>
  );
};

export default AdminCustomer;
