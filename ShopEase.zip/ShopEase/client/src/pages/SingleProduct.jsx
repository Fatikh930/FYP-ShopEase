import React, { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Tab, Disclosure, RadioGroup } from "@headlessui/react";
import { HeartIcon } from "@heroicons/react/24/solid";
import { Reviews } from "../components";
import { useDispatch } from "react-redux";
import { addItemToCart } from "../features/Cart/CartSlice";
import useAuth from "../Hooks/AuthHook";
import axios from "axios";

const SingleProduct = () => {
  let { id } = useParams();
  const [product, setProduct] = useState(null);
  const [selectedTab, setSelectedTab] = useState(1);
  const [isAdding, setIsAdding] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);
  const { isAuthenticated, isLoading, user } = useAuth();
  const [review, setReview] = useState({
    title: "",
    rating: 0,
    comment: "",
  });
  const [reviews, setReviews] = useState([]);

  console.log("thsi is id", id);
  console.log("this is user id", user?._id);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/api/products/get-product/${id}`
        );
        setProduct(response.data.product);
        console.log("this is a product lll", response.data.product);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching product:", error);
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };

    const fetchReviews = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/api/products/get-reviews/${id}`
        );
        setReviews(response.data.reviews);
      } catch (error) {
        console.error("Error fetching reviews:", error);
      }
    };

    fetchProduct();
    fetchReviews();
  }, [id]);

  const handleAddToCart = async () => {
    try {
      const response = await axios.post("/api/users/add-to-cart", {
        productId: product._id,
      });
      console.log(response.data.message);
    } catch (error) {
      console.error("Error adding product to cart:", error);
    }
  };

  const handleAddToWishlist = async () => {
    try {
      const response = await axios.post("/api/users/add-to-wishlist", {
        productId: product._id,
      });
      console.log(response.data.message);
    } catch (error) {
      console.error("Error adding product to cart:", error);
    }
  };

  const generateStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      const starClass = i <= rating ? "text-blue-400" : "text-gray-300";
      stars.push(
        <svg
          key={i}
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
          className={`h-5 w-5 shrink-0 ${starClass}`}
        >
          <path
            fillRule="evenodd"
            d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
            clipRule="evenodd"
          ></path>
        </svg>
      );
    }
    return stars;
  };

  const handleReviewChange = (e) => {
    const { name, value } = e.target;
    setReview((prevReview) => ({
      ...prevReview,
      [name]: value,
    }));
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        `http://localhost:8000/api/products/add-review/${id}`,
        {
          user: user?._id,
          ...review,
        }
      );
      console.log(response.data.message);
      setReview({ title: "", rating: 0, comment: "" });
      // Refresh reviews after adding a new review
      const fetchReviews = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8000/api/products/get-reviews/${id}`
          );
          setReviews(response.data.reviews);
        } catch (error) {
          console.error("Error fetching reviews:", error);
        }
      };
      fetchReviews();
    } catch (error) {
      console.error("Error adding review:", error);
    }
  };

  return (
    <>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <>
          <div className="bg-white">
            <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-24 lg:max-w-7xl lg:px-8">
              <div className="lg:grid lg:grid-cols-2 lg:items-start lg:gap-x-8">
                <Tab.Group
                  onChange={(index) => setSelectedTab(index + 1)}
                  selectedIndex={selectedTab - 1}
                >
                  <div className="flex flex-col-reverse">
                    <Tab.Panels className="aspect-h-1 aspect-w-1 w-full">
                      <Tab.Panel>
                        <img
                          src={product.productImage}
                          alt={product.name}
                          className="h-full w-full object-cover object-center sm:rounded-lg"
                        />
                      </Tab.Panel>
                    </Tab.Panels>
                  </div>
                  <div className="mt-10 px-4 sm:mt-16 sm:mx-0 lg:mt-0">
                    <h1 className="text-3xl font-bold tracking-tight text-gray-900">
                      {product.name}
                    </h1>
                    <div className="mt-3">
                      <p className="text-3xl tracking-tight text-gray-900">
                        Rs {product.price}
                      </p>
                    </div>
                    <div className="mt-3">
                      <div className="flex items-center">
                        {/* {generateStars(product.rating)} */}
                      </div>
                    </div>
                    <div className="mt-6">
                      <div className="space-y-6 text-base text-gray-700">
                        <p>{product.description}</p>
                      </div>
                    </div>
                    <div className="mt-10 flex flex-col gap-4">
                      <div className="flex gap-5">
                        <button
                          type="submit"
                          className={`flex max-w-xs flex-1 items-center justify-center rounded-md border border-transparent bg-blue-500 px-8 text-base font-medium text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-gray-50 sm:w-full ${
                            isAdding ? "animate-pulse" : ""
                          }`}
                          onClick={handleAddToCart}
                        >
                          {isAdding ? "Adding..." : "Add to Cart"}
                        </button>

                        <button
                          type="submit"
                          className={`flex max-w-xs flex-1 items-center justify-center rounded-md border border-transparent bg-gray-100 px-8 py-3 text-base font-medium text-blue-500 hover:text-blue-600 hover:bg-blue-600. focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-gray-50 sm:w-full ${
                            isAdding ? "animate-pulse" : ""
                          }`}
                          onClick={handleAddToWishlist}
                        >
                          <HeartIcon className="h-6 w-6 " /> Add to Wishlist
                        </button>
                      </div>
                      <Link
                        to={`/arpage/${product._id}`}
                        type="button"
                        className=" w-full flex items-center justify-center rounded-md px-3 py-3  text-white bg-blue-500 hover:bg-blue-600 font-medium"
                      >
                        <span>View AR</span>
                      </Link>
                    </div>
                    <div className="mt-10">
                      <h2 className="text-2xl font-bold tracking-tight text-gray-900">
                        Add Review
                      </h2>
                      <form
                        className="mt-4 space-y-6"
                        onSubmit={handleReviewSubmit}
                      >
                        <div>
                          <label
                            htmlFor="title"
                            className="block text-sm font-medium text-gray-700"
                          >
                            Title
                          </label>
                          <input
                            type="text"
                            name="title"
                            id="title"
                            value={review.title}
                            onChange={handleReviewChange}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                          />
                        </div>
                        <div>
                          <label
                            htmlFor="rating"
                            className="block text-sm font-medium text-gray-700"
                          >
                            Rating
                          </label>
                          <input
                            type="number"
                            name="rating"
                            id="rating"
                            value={review.rating}
                            onChange={handleReviewChange}
                            min="1"
                            max="5"
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                          />
                        </div>
                        <div>
                          <label
                            htmlFor="comment"
                            className="block text-sm font-medium text-gray-700"
                          >
                            Comment
                          </label>
                          <textarea
                            name="comment"
                            id="comment"
                            value={review.comment}
                            onChange={handleReviewChange}
                            rows="4"
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                          />
                        </div>
                        <button
                          type="submit"
                          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                          Submit Review
                        </button>
                      </form>
                    </div>
                  </div>
                </Tab.Group>
              </div>
            </div>
          </div>
          <Reviews reviews={reviews} />
        </>
      )}
    </>
  );
};

export default SingleProduct;
