import React from "react";
import { AdminHeader } from "../components";
import CreateProduct from "./CreateProduct";

const AdminProducts = () => {
  const text = "Products";
  return (
    <>
      <AdminHeader text={text} />
      <CreateProduct />
    </>
  );
};

export default AdminProducts;
