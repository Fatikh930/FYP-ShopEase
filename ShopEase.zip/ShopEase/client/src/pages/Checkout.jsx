import { CheckoutForm, CheckoutOrderSummary } from "../components";
// import { useLocation } from "react-router-dom";

const Checkout = () => {
  // const location = useLocation();
  // const { cartItems, orderTotal } = location.state || {};

  return (
    <div className="bg-gray-50">
      <div className="mx-auto max-w-2xl px-4 pb-24 pt-16 sm:px-6 lg:max-w-7xl lg:px-8">
        <h2 className="sr-only">Checkout</h2>
        <form className="lg:grid lg:grid-cols-2 lg:gap-x-12 xl:gap-x-16">
          {/* <CheckoutForm cartItems={cartItems} />
          <CheckoutOrderSummary orderTotal={orderTotal} /> */}
          <CheckoutForm />
          <CheckoutOrderSummary />
        </form>
      </div>
    </div>
  );
};

export default Checkout;
