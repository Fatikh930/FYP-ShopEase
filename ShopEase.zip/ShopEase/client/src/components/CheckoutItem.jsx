import React, { useState } from "react";
import { Listbox } from "@headlessui/react";
import {
  ChevronDownIcon,
  CheckIcon,
  TrashIcon,
} from "@heroicons/react/20/solid";
import { useDispatch, useSelector } from "react-redux";
import { FormatPrice } from "../components";
import {
  removeItemFromCart,
  updateCartItemQuantity,
} from "../features/Cart/CartSlice";

const CheckoutItem = ({ item }) => {
  const dispatch = useDispatch();

  const [selectedQuantity, setSelectedQuantity] = useState(item.quantity || 1);
  const availableQuantity = item.availableStock;
  console.log("available quantity", availableQuantity);

  const handleRemoveItem = () => {
    setSelectedQuantity((prevSelectedQuantity) => prevSelectedQuantity - 1);
    dispatch(removeItemFromCart(item.id));
  };

  const handleQuantityChange = (quantity) => {
    setSelectedQuantity(quantity);
    dispatch(updateCartItemQuantity({ id: item.id, quantity }));
  };

  const quantities = Array.from({ length: availableQuantity }, (_, i) => i + 1);

  return (
    <li className="flex px-4 py-6 sm:px-6">
      <div className="shrink-0">
        <img
          src={item.images[0]}
          alt="Front of men's Basic Tee in black."
          className="w-20 rounded-md"
        />
      </div>
      <div className="ml-6 flex flex-1 flex-col">
        <div className="flex">
          <div className="min-w-0 flex-1">
            <h4 className="text-sm">
              <a
                href="#"
                className="font-medium text-gray-700 hover:text-gray-800"
              >
                {item.name}
              </a>
            </h4>
          </div>
          <div className="ml-4 flow-root shrink-0">
            <button
              type="button"
              className="-m-2.5 flex items-center justify-center bg-white p-2.5 text-gray-400 hover:text-gray-500"
              onClick={handleRemoveItem}
            >
              <span className="sr-only">Remove</span>
              <TrashIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div className="flex flex-1 items-end justify-between pt-2">
          <p className="mt-1 text-sm font-medium text-gray-900">
            <FormatPrice price={item.price} />
          </p>
          <div className="ml-4">
            <label htmlFor="quantity" className="sr-only">
              Quantity
            </label>
            <Listbox value={item.quantity || 1} onChange={handleQuantityChange}>
              <Listbox.Button className="relative w-full rounded-md border border-gray-300 shadow-sm pl-3 pr-10 py-2 text-left focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400 sm:text-sm">
                <span className="block truncate">{selectedQuantity}</span>
                <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                  <ChevronDownIcon
                    className="h-5 w-5 text-gray-400"
                    aria-hidden="true"
                  />
                </span>
              </Listbox.Button>

              <Listbox.Options className="absolute z-10 mt-1 max-h-60  overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                {quantities.map((quantity) => (
                  <Listbox.Option
                    key={quantity}
                    value={quantity}
                    className={({ active }) =>
                      `relative cursor-default select-none py-2 pl-3 pr-9 ${
                        active ? "bg-blue-100 text-blue-900" : "text-gray-900"
                      }`
                    }
                  >
                    {({ selected }) => (
                      <>
                        {selected && (
                          <span className="absolute inset-y-0 right-0 flex items-center pr-4 text-blue-600">
                            <CheckIcon className="h-5 w-5" aria-hidden="true" />
                          </span>
                        )}
                        <span
                          className={`block truncate ${
                            selected ? "font-medium" : "font-normal"
                          }`}
                        >
                          {quantity}
                        </span>
                      </>
                    )}
                  </Listbox.Option>
                ))}
              </Listbox.Options>
            </Listbox>
          </div>
        </div>
      </div>
    </li>
  );
};

export default CheckoutItem;
