import { Fragment, useState, useEffect } from "react";
import { useMediaQuery } from "react-responsive";
import { useLocation } from "react-router-dom";
import { Dialog, Disclosure, Menu, Transition } from "@headlessui/react";
import {
  XMarkIcon,
  ChevronDownIcon,
  FunnelIcon,
  MinusIcon,
  PlusIcon,
  Squares2X2Icon,
  ListBulletIcon,
} from "@heroicons/react/24/outline";
import {
  ProductCard,
  ProductCardHorizontal,
  Pagination,
  Search,
} from "../components";
import useAuth from "../Hooks/AuthHook";
import axios from "axios";

const sortOptions = [
  { value: "default", name: "Best Rating", current: true },
  { value: "newest", name: "Newest", current: false },
  { value: "lowToHigh", name: "Price: Low to High", current: false },
  { value: "highToLow", name: "Price: High to Low", current: false },
];

const categoryOptions = [
  { value: "all", name: "All" },
  { value: "Shoes", name: "Shoes" },
  { value: "Glasses", name: "Glasses" },
  { value: "Caps", name: "Caps" },
  { value: "Watches", name: "Watches" },
  { value: "Necklaces", name: "Necklaces" },
];

const subCategories = [
  { value: "all-products", label: "All Products" },
  { value: "men", label: "Men" },
  { value: "women", label: "Women" },
];

const classNames = (...classes) => classes.filter(Boolean).join(" ");

export default function CategoryFilters({ category, products }) {
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [selectedSubCategory, setSelectedSubCategory] =
    useState("all-products");
  const [sortOption, setSortOption] = useState("default");
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(9);
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  const { state } = location;
  const { category: initialSelectedCategory } = state || {};
  const [selectedCategory, setSelectedCategory] = useState(
    initialSelectedCategory || "all"
  );
  const [viewType, setViewType] = useState("grid");
  const [filteredProducts, setFilteredProducts] = useState(products);
  const isSmallScreen = useMediaQuery({ query: "(max-width: 639px)" });

  useEffect(() => {
    if (isSmallScreen) setViewType("grid");
  }, [isSmallScreen]);

  useEffect(() => {
    const filtered = products
      .filter(
        (product) =>
          selectedCategory === "all" || product.category === selectedCategory
      )
      .filter(
        (product) =>
          selectedSubCategory === "all-products" ||
          product.type === selectedSubCategory
      );
    setFilteredProducts(filtered);
  }, [selectedCategory, selectedSubCategory, products]);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredProducts.slice(
    indexOfFirstPost,
    indexOfLastPost
  );
  const totalPages = Math.ceil(filteredProducts.length / postsPerPage);

  const handlePageChange = (page) => setCurrentPage(page);
  const handleViewTypeChange = (viewType) => setViewType(viewType);
  const handleSortOptionClick = (value) => {
    setSortOption(value);
    sortOptions.forEach((option) => (option.current = option.value === value));
  };

  const handleSearch = async (searchTerm) => {
    try {
      const response = await axios.get(
        `/api/products/search?name=${searchTerm}`
      );
      setFilteredProducts(response.data.products);
    } catch (error) {
      console.error("Error fetching search results:", error);
    }
  };

  const sortProducts = (products, sortOption) => {
    switch (sortOption) {
      case "newest":
        return products.sort(
          (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
        );
      case "lowToHigh":
        return products.sort(
          (a, b) => parseFloat(a.price) - parseFloat(b.price)
        );
      case "highToLow":
        return products.sort(
          (a, b) => parseFloat(b.price) - parseFloat(a.price)
        );
      default:
        return products;
    }
  };

  return (
    <div className="bg-white">
      <div>
        {/* Mobile filter dialog */}
        <Transition.Root show={mobileFiltersOpen} as={Fragment}>
          <Dialog
            as="div"
            className="relative z-40 lg:hidden"
            onClose={setMobileFiltersOpen}
          >
            <Transition.Child
              as={Fragment}
              enter="transition-opacity ease-linear duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="transition-opacity ease-linear duration-300"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className="fixed inset-0 bg-black bg-opacity-25" />
            </Transition.Child>
            <div className="fixed inset-0 z-40 flex">
              <Transition.Child
                as={Fragment}
                enter="transition ease-in-out duration-300 transform"
                enterFrom="translate-x-full"
                enterTo="translate-x-0"
                leave="transition ease-in-out duration-300 transform"
                leaveFrom="translate-x-0"
                leaveTo="translate-x-full"
              >
                <Dialog.Panel className="relative ml-auto flex h-full w-full max-w-xs flex-col overflow-y-auto bg-white py-4 pb-12 shadow-xl">
                  <div className="flex items-center justify-between px-4">
                    <h2 className="text-lg font-medium text-gray-900">
                      Filters
                    </h2>
                    <button
                      type="button"
                      className="-mr-2 flex h-10 w-10 items-center justify-center rounded-md bg-white p-2 text-gray-400"
                      onClick={() => setMobileFiltersOpen(false)}
                    >
                      <span className="sr-only">Close menu</span>
                      <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                    </button>
                  </div>
                  <form className="mt-4 border-t border-gray-200">
                    <Disclosure
                      as="div"
                      className="border-t border-gray-200 px-4 py-6"
                    >
                      {({ open }) => (
                        <>
                          <h3 className="-mx-2 -my-3 flow-root">
                            <Disclosure.Button className="flex w-full items-center justify-between bg-white px-2 py-3 text-gray-400 hover:text-gray-500">
                              <span className="font-medium text-gray-900">
                                Category
                              </span>
                              <span className="ml-6 flex items-center">
                                {open ? (
                                  <MinusIcon
                                    className="h-5 w-5"
                                    aria-hidden="true"
                                  />
                                ) : (
                                  <PlusIcon
                                    className="h-5 w-5"
                                    aria-hidden="true"
                                  />
                                )}
                              </span>
                            </Disclosure.Button>
                          </h3>
                          <Disclosure.Panel className="pt-6">
                            <div className="space-y-6">
                              {categoryOptions.map((option) => (
                                <div
                                  key={option.value}
                                  className="flex items-center"
                                >
                                  <input
                                    id={`filter-mobile-category-${option.value}`}
                                    name="category"
                                    type="radio"
                                    checked={option.value === selectedCategory}
                                    onChange={() =>
                                      setSelectedCategory(option.value)
                                    }
                                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                  />
                                  <label
                                    htmlFor={`filter-mobile-category-${option.value}`}
                                    className="ml-3 min-w-0 flex-1 text-gray-500"
                                  >
                                    {option.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                          </Disclosure.Panel>
                        </>
                      )}
                    </Disclosure>
                    <Disclosure
                      as="div"
                      className="border-t border-gray-200 px-4 py-6"
                    >
                      {({ open }) => (
                        <>
                          <h3 className="-mx-2 -my-3 flow-root">
                            <Disclosure.Button className="flex w-full items-center justify-between bg-white px-2 py-3 text-gray-400 hover:text-gray-500">
                              <span className="font-medium text-gray-900">
                                SubCategory
                              </span>
                              <span className="ml-6 flex items-center">
                                {open ? (
                                  <MinusIcon
                                    className="h-5 w-5"
                                    aria-hidden="true"
                                  />
                                ) : (
                                  <PlusIcon
                                    className="h-5 w-5"
                                    aria-hidden="true"
                                  />
                                )}
                              </span>
                            </Disclosure.Button>
                          </h3>
                          <Disclosure.Panel className="pt-6">
                            <div className="space-y-6">
                              {subCategories.map((option) => (
                                <div
                                  key={option.value}
                                  className="flex items-center"
                                >
                                  <input
                                    id={`filter-mobile-subcategory-${option.value}`}
                                    name="subcategory"
                                    type="radio"
                                    checked={
                                      option.value === selectedSubCategory
                                    }
                                    onChange={() =>
                                      setSelectedSubCategory(option.value)
                                    }
                                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                  />
                                  <label
                                    htmlFor={`filter-mobile-subcategory-${option.value}`}
                                    className="ml-3 min-w-0 flex-1 text-gray-500"
                                  >
                                    {option.label}
                                  </label>
                                </div>
                              ))}
                            </div>
                          </Disclosure.Panel>
                        </>
                      )}
                    </Disclosure>
                  </form>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </Dialog>
        </Transition.Root>
        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-baseline justify-between border-b border-gray-200 pb-6 pt-24">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900">
              New Arrivals
            </h1>
            <div className="flex items-center ml-auto">
              <Search onSearch={handleSearch} />

              <button
                type="button"
                className="-m-2 ml-5 p-2 text-gray-400 hover:text-gray-500 sm:ml-7"
                onClick={() => setMobileFiltersOpen(true)}
              >
                <span className="sr-only">Filters</span>
                <FunnelIcon className="h-5 w-5" aria-hidden="true" />
              </button>
              <button
                type="button"
                className="-m-2 ml-5 p-2 text-gray-400 hover:text-gray-500 sm:ml-7"
                onClick={() =>
                  handleViewTypeChange(viewType === "grid" ? "list" : "grid")
                }
              >
                <span className="sr-only">
                  {viewType === "grid" ? "List view" : "Grid view"}
                </span>
                {viewType === "grid" ? (
                  <ListBulletIcon className="h-5 w-5" aria-hidden="true" />
                ) : (
                  <Squares2X2Icon className="h-5 w-5" aria-hidden="true" />
                )}
              </button>
            </div>
          </div>
          <section aria-labelledby="products-heading" className="pb-24 pt-6">
            <h2 id="products-heading" className="sr-only">
              Products
            </h2>
            <div className="grid grid-cols-1 gap-x-8 gap-y-10 lg:grid-cols-4">
              <aside>
                <h3 className="sr-only">Categories</h3>
                <div className="hidden lg:block">
                  <form className="space-y-10 divide-y divide-gray-200">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        Category
                      </h3>
                      <div className="pt-6">
                        <div className="space-y-4">
                          {categoryOptions.map((option) => (
                            <div
                              key={option.value}
                              className="flex items-center"
                            >
                              <input
                                id={`filter-category-${option.value}`}
                                name="category"
                                type="radio"
                                checked={option.value === selectedCategory}
                                onChange={() =>
                                  setSelectedCategory(option.value)
                                }
                                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                              />
                              <label
                                htmlFor={`filter-category-${option.value}`}
                                className="ml-3 text-sm text-gray-600"
                              >
                                {option.name}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="pt-10">
                      <h3 className="text-lg font-medium text-gray-900">
                        Filter by Gender
                      </h3>
                      <div className="pt-6">
                        <div className="space-y-4">
                          {subCategories.map((option) => (
                            <div
                              key={option.value}
                              className="flex items-center"
                            >
                              <input
                                id={`filter-subcategory-${option.value}`}
                                name="subcategory"
                                type="radio"
                                checked={option.value === selectedSubCategory}
                                onChange={() =>
                                  setSelectedSubCategory(option.value)
                                }
                                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                              />
                              <label
                                htmlFor={`filter-subcategory-${option.value}`}
                                className="ml-3 text-sm text-gray-600"
                              >
                                {option.label}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </aside>
              <div className="lg:col-span-3">
                <div
                  className={
                    viewType === "grid"
                      ? "grid grid-cols-1 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 lg:gap-x-8"
                      : "space-y-6"
                  }
                >
                  {sortProducts(currentPosts, sortOption).map((product) =>
                    viewType === "grid" ? (
                      <ProductCard key={product._id} product={product} />
                    ) : (
                      <ProductCardHorizontal
                        key={product._id}
                        product={product}
                      />
                    )
                  )}
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={handlePageChange}
                />
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
