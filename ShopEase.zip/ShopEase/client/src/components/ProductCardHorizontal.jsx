import React, { useState } from "react";
import { FormatPrice } from "../components";
import { useDispatch } from "react-redux";
import { addItemToCart } from "../features/Cart/CartSlice";
import { Link, useNavigate } from "react-router-dom";

const ProductCardHorizontal = ({ product, isAuthenticated }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  return (
    <div className="flex font-sans">
      <div className="flex-none w-64 relative">
        <img
          src={product.productImage}
          alt="Product image"
          className="absolute inset-0 w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <form className="flex-auto p-6">
        <div className="flex flex-wrap">
          <h1 className="flex-auto text-lg font-semibold text-slate-900">
            {product.name}
          </h1>
          <div className="text-lg font-semibold text-slate-500">
            Rs {product.price}
          </div>
          <div className="w-full flex-none text-sm font-medium text-slate-700 mt-2">
            In stock
          </div>
        </div>
        <div className="flex items-baseline mt-4 mb-6 pb-6 border-b border-slate-200">
          {product.description}
        </div>
        <div className="flex space-x-4 mb-6 text-sm font-medium">
          <div className="flex-auto flex space-x-4">
            <Link to={`/product/${product._id}`}>
              <button
                className={`h-10 px-6 font-semibold rounded-md border border-slate-200 text-slate-900 hover:bg-slate-100`}
              >
                View Product
              </button>
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ProductCardHorizontal;
