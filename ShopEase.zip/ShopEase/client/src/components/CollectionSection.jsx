import React from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setCategory } from "../features/Category/CategorySlice";

const CollectionSection = () => {
  const dispatch = useDispatch();

  return (
    <div className="bg-transparent">
      <div className="mx-auto max-w-[90rem] px-4 py-16 sm:px-6 sm:py-24 lg:mx-8">
        <div className="sm:flex sm:items-baseline sm:justify-between">
          <h2 className="text-2xl font-bold tracking-tight text-gray-900">
            Shop by Category
          </h2>
        </div>
        <div className="mt-6 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:grid-rows-2 sm:gap-x-6 lg:gap-8">
          <div className="hover:opacity-75 aspect-h-1 aspect-w-2 overflow-hidden rounded-lg sm:aspect-h-1 sm:aspect-w-1 sm:row-span-2">
            <img
              src="https://source.unsplash.com/u79wy47kvVs"
              alt="Some accessories on a table. Shoes, glasses, and bags."
              className="object-cover object-center hover:opacity-75"
            />
            <div
              aria-hidden="true"
              className="bg-gradient-to-b from-transparent to-black opacity-75"
            ></div>
            <div className="flex items-end p-6">
              <div>
                <h3 className="font-semibold text-white">
                  <Link to="/products">
                    <span className="absolute inset-0"></span>New Arrivals
                  </Link>
                </h3>
                <p aria-hidden="true" className="mt-1 text-sm text-white">
                  All the latest trends
                </p>
              </div>
            </div>
          </div>
          <div className="hover:opacity-75 aspect-h-1 aspect-w-2 overflow-hidden rounded-lg sm:pb-0 sm:relative sm:h-full">
            <img
              src="https://source.unsplash.com/tmtizwShVRo"
              alt="A man wearing glasses and looking at the camera."
              className="object-cover object-center hover:opacity-75 sm:absolute sm:inset-0 sm:h-full sm:w-full"
            />
            <div
              aria-hidden="true"
              className="bg-gradient-to-b from-transparent to-black opacity-75 sm:absolute sm:inset-0"
            ></div>
            <div className="flex items-end p-6 sm:absolute sm:inset-0">
              <div>
                <h3 className="font-semibold text-white">
                  <Link
                    to="/products"
                    state={{ category: "men" }}
                    onClick={() => dispatch(setCategory("men"))} // dispatch setCategory action when user clicks on the link
                  >
                    <span className="absolute inset-0"></span>Men
                  </Link>
                </h3>
                <p aria-hidden="true" className="mt-1 text-sm text-white">
                  Shop now
                </p>
              </div>
            </div>
          </div>
          <div className="hover:opacity-75 aspect-h-1 aspect-w-2 overflow-hidden rounded-lg sm:pb-0 sm:relative sm:h-full">
            <img
              src="https://source.unsplash.com/UGR7ArHKqcc"
              alt="A women wearing glasses."
              className="object-cover object-center hover:opacity-75 sm:absolute sm:inset-0 sm:h-full sm:w-full"
            />
            <div
              aria-hidden="true"
              className="bg-gradient-to-b from-transparent to-black opacity-75 sm:absolute sm:inset-0"
            ></div>
            <div className="flex items-end p-6 sm:absolute sm:inset-0">
              <div>
                <h3 className="font-semibold text-white">
                  <Link
                    to="/products"
                    state={{ category: "women" }}
                    onClick={() => dispatch(setCategory("women"))} // dispatch setCategory action when user clicks on the link
                  >
                    <span className="absolute inset-0"></span>Women
                  </Link>
                </h3>
                <p aria-hidden="true" className="mt-1 text-sm text-white">
                  Shop now
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollectionSection;
