import React from "react";
import { adidas, armour, gucci, nike, puma } from "../assets";

const LogoClouds = () => {
  return (
    <div className="bg-white py-16">
      {/*background gradient*/}
      <div
        className="absolute border inset-x-0 z-10 transform-gpu blur-3xl overflow-hidden"
        aria-hidden="true"
      >
        <div
          className="relative  aspect-[1155/678] h-[24rem] sm:h-[20rem] lg:h-[15rem] w-[40rem] sm:w-[70rem]  rotate-[180deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 "
          style={{
            clipPath:
              "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
          }}
        ></div>
      </div>

      <div className="mx-auto max-w-[90rem] px-6 lg:px-8">
        <h2 className="text-center text-lg font-semibold leading-8 text-gray-900">
          Trusted by the world’s most innovative brands
        </h2>
        <div className="mx-auto mt-10 grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-5">
          <img
            className="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
            src={nike}
            alt="Nike"
            width="158"
            height="48"
          />
          <img
            className="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
            src={adidas}
            alt="Adidas"
            width="158"
            height="48"
          />
          <img
            className="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
            src={puma}
            alt="Puma"
            width="158"
            height="48"
          />
          <img
            className="col-span-2 max-h-12 w-full object-contain sm:col-start-2 lg:col-span-1"
            src={armour}
            alt="Armour"
            width="158"
            height="48"
          />
          <img
            className="col-span-2 col-start-2 max-h-12 w-full object-contain sm:col-start-auto lg:col-span-1"
            src={gucci}
            alt="Gucci"
            width="158"
            height="48"
          />
        </div>
      </div>
    </div>
  );
};

export default LogoClouds;
