import React from "react";

const OurValuesSection = () => {
  return (
    <div className="mx-auto mt-32 max-w-7xl px-6 sm:mt-40">
      <div className="mx-auto max-w-2xl lg:mx-0">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
          Our values
        </h2>
        <p className="mt-6 text-lg leading-8 text-gray-600">
          Our values center on integrity, innovation, and inclusivity, guiding
          us to deliver exceptional experiences and foster diverse communities.
        </p>
      </div>
      <dl className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 text-base leading-7 sm:grid-cols-2 lg:grid-cols-3 lg:max-w-none lg:mx-0">
        <div>
          <dt className="font-semibold text-gray-900">Be world-Class</dt>
          <dd className="mt-1 text-gray-600">
            Our relentless pursuit of excellence, fearless innovation, and
            commitment to exceeding expectations drive us to be world-class in
            everything we do.
          </dd>
        </div>
        <div>
          <dt className="font-semibold text-gray-900">
            Share everything you know
          </dt>
          <dd className="mt-1 text-gray-600">
            Embrace the ethos of sharing knowledge openly and generously; it's
            through this collaborative spirit that we empower others and foster
            collective growth and success.
          </dd>
        </div>
        <div>
          <dt className="font-semibold text-gray-900">Always learning</dt>
          <dd className="mt-1 text-gray-600">
            Embrace the journey of perpetual learning, where curiosity fuels
            growth. We strive to absorb, adapt, and evolve, fostering a culture
            of continuous improvement and innovation.
          </dd>
        </div>
        <div>
          <dt className="font-semibold text-gray-900">Be supportive</dt>
          <dd className="mt-1 text-gray-600">
            We cultivate an environment of unwavering support, lifting each
            other up in times of challenge and celebration. Together, we thrive
            through empathy, encouragement, and collective empowerment.
          </dd>
        </div>
        <div>
          <dt className="font-semibold text-gray-900">Take responsibility</dt>
          <dd className="mt-1 text-gray-600">
            We embrace accountability, taking ownership of our actions and their
            consequences. Through responsibility, we empower ourselves to drive
            positive change and uphold integrity in all endeavors.
          </dd>
        </div>
        <div>
          <dt className="font-semibold text-gray-900">Enjoy downtime</dt>
          <dd className="mt-1 text-gray-600">
            Embrace the value of downtime, fostering balance and rejuvenation.
            By savoring moments of relaxation and recreation, we replenish our
            energy and inspire creativity for greater productivity.
          </dd>
        </div>
      </dl>
    </div>
  );
};

export default OurValuesSection;
