import React from "react";
import { nike } from "../assets";

const Testimonial = () => {
  return (
    <div className="relative isolate bg-white pb-32 pt-24 sm:pt-32">
      {/* Decorative background */}
      <div
        className="absolute inset-x-0 top-1/2 -z-10 -translate-y-1/2 transform-gpu overflow-hidden opacity-30 blur-3xl"
        aria-hidden="true"
      >
        <div
          className="ml-[max(50%,38rem)] aspect-[1313/771] w-[82rem] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc]"
          style={{
            clipPath:
              "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
          }}
        ></div>
      </div>
      <div
        className="absolute inset-x-0 top-0 -z-10 flex transform-gpu overflow-hidden pt-32 opacity-25 blur-3xl sm:pt-40 xl:justify-end"
        aria-hidden="true"
      >
        <div
          className="-ml-[22rem] aspect-[1313/771] w-[82rem] flex-none origin-top-right rotate-[30deg]  bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] xl:ml-0 xl:mr-[calc(50%-12rem)]"
          style={{
            clipPath:
              "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
          }}
        ></div>
      </div>

      {/* Testimonial Content */}
      <div className="mx-auto max-w-[90rem] px-6 lg:px-8">
        {/* Testimonial Heading */}
        <div className="mx-auto max-w-xl text-center">
          <h2 className="text-lg font-semibold leading-8 tracking-tight text-blue-500">
            Testimonials
          </h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            We have worked with thousands of amazing people
          </p>
        </div>
        {/* Testimonial Cards */}
        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 grid-rows-1 gap-8 text-sm leading-6 text-gray-900 sm:mt-20 sm:grid-cols-2 xl:mx-0 xl:max-w-none xl:grid-flow-col xl:grid-cols-4">
          <figure className="rounded-2xl bg-white shadow-lg ring-1 ring-gray-900/5 sm:col-span-2 xl:col-start-2 xl:row-end-1">
            <blockquote className="p-6 text-lg font-semibold leading-7 tracking-tight text-gray-900 sm:p-12 sm:text-xl sm:leading-8">
              <p>
                “The glasses I bought are stylish, lightweight, and complement
                my outfits perfectly. Truly an excellent purchase!”
              </p>
            </blockquote>
            <figcaption className="flex flex-wrap items-center gap-x-4 gap-y-4 border-t border-gray-900/10 px-6 py-4 sm:flex-nowrap">
              <img
                className="h-10 w-10 flex-none rounded-full bg-gray-50"
                src="https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=1024&amp;h=1024&amp;q=80"
                alt=""
              />
              <div className="flex-auto">
                <div className="font-semibold">Brenna Goyette</div>
                <div className="text-gray-600">@brennagoyette</div>
              </div>
              <img className="h-10 w-auto flex-none" src={nike} alt="" />
            </figcaption>
          </figure>
          <div className="space-y-8 xl:contents xl:space-y-0">
            <div className="xl:row-span-2 space-y-8">
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The shoes I ordered are incredibly comfortable, and the
                    design is modern. I love every step I take.”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Leslie Alexander</div>
                    <div className="text-gray-600">@lesliealexander</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The watch I received is a masterpiece. It's well-crafted,
                    elegant, and runs like a dream. A superb timepiece!”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Michael Foster</div>
                    <div className="text-gray-600">@michaelfoster</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The sunglasses I picked up are chic and protect my eyes.
                    They add flair to my style effortlessly”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Dries Vincent</div>
                    <div className="text-gray-600">@driesvincent</div>
                  </div>
                </figcaption>
              </figure>
            </div>
            <div className="xl:row-start-1 space-y-8">
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “My jewelry purchase exceeded expectations. The pieces are
                    delicate, stunning, and shine brilliantly. I'm thrilled with
                    my collection”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Lindsay Walton</div>
                    <div className="text-gray-600">@lindsaywalton</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The men's watch I chose is a symbol of craftsmanship and
                    sophistication. It's a timeless accessory, worth every
                    penny”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Courtney Henry</div>
                    <div className="text-gray-600">@courtneyhenry</div>
                  </div>
                </figcaption>
              </figure>
            </div>
          </div>
          <div className="space-y-8 xl:contents xl:space-y-0">
            <div className="xl:row-start-1 space-y-8">
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The watch I ordered arrived promptly and looks impressive
                    on my wrist. A blend of luxury and functionality”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Tom Cook</div>
                    <div className="text-gray-600">@tomcook</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “My new eyeglasses are fashionable and comfortable. I
                    receive compliments daily. A fantastic blend of form and
                    function”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1517365830460-955ce3ccd263?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Whitney Francis</div>
                    <div className="text-gray-600">@whitneyfrancis</div>
                  </div>
                </figcaption>
              </figure>
            </div>
            <div className="xl:row-span-2 space-y-8">
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “The jewelry I bought online is classy and versatile. Each
                    piece complements my style effortlessly. Highly recommended”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Leonard Krasner</div>
                    <div className="text-gray-600">@leonardkrasner</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “My online shoe shopping experience here has been superb. I
                    found the perfect pair for every occasion”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Floyd Miles</div>
                    <div className="text-gray-600">@floydmiles</div>
                  </div>
                </figcaption>
              </figure>
              <figure className="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-gray-900/5">
                <blockquote className="text-gray-900">
                  <p>
                    “My new eyeglasses are fashionable and comfortable. I
                    receive compliments daily. A fantastic blend of form and
                    function”
                  </p>
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-x-4">
                  <img
                    className="h-10 w-10 rounded-full bg-gray-50"
                    src="https://images.unsplash.com/photo-1502685104226-ee32379fefbe?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=facearea&amp;facepad=2&amp;w=256&amp;h=256&amp;q=80"
                    alt=""
                  />
                  <div>
                    <div className="font-semibold">Emily Selman</div>
                    <div className="text-gray-600">@emilyselman</div>
                  </div>
                </figcaption>
              </figure>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
