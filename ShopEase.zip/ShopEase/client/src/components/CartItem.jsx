import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  removeItemFromCart,
  updateCartItemQuantity,
} from "../features/Cart/CartSlice";
import { Listbox, Transition } from "@headlessui/react";
import {
  CheckIcon,
  ChevronUpDownIcon,
  TrashIcon,
} from "@heroicons/react/20/solid";
import axios from "axios";

const CartItem = ({ item }) => {
  const dispatch = useDispatch();

  const [selectedQuantity, setSelectedQuantity] = useState(item.quantity || 1);
  const availableQuantity = item.availableStock;
  console.log("available quantity", availableQuantity);

  const handleRemoveItem = async () => {
    try {
      const response = await axios.post("/api/users/remove-from-cart", {
        productId: item.product._id,
      });
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleQuantityChange = (quantity) => {
    setSelectedQuantity(quantity);
    dispatch(updateCartItemQuantity({ id: item.id, quantity }));
  };

  const quantities = Array.from({ length: availableQuantity }, (_, i) => i + 1);

  return (
    <li className="flex py-6 sm:py-10">
      <div className="shrink-0">
        <img
          src={item.product.productImage}
          alt={item.product.description}
          className="h-24 w-24 rounded-md object-cover object-center sm:h-48 sm:w-48"
        />
      </div>
      <div className="ml-4 flex flex-1 flex-col justify-between sm:ml-6">
        <div className="relative pr-9 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:pr-0">
          <div>
            <div className="flex justify-between">
              <h3 className="text-sm">
                <a
                  href="#"
                  className="font-medium text-gray-700 hover:text-gray-800"
                >
                  {item.product.name}
                </a>
              </h3>
            </div>
            <div className="mt-1 flex text-sm">
              {/* <p className="text-gray-500">{item.color}</p> */}
              <p className="ml-4 border-l border-gray-200 pl-4 text-gray-500">
                {/* {item.size} */}
              </p>
            </div>
            <p className="mt-1 text-sm font-medium text-gray-900">
              Rs {item.product.price}
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:pr-9">
            <div className="flex items-center justify-between">
              <div className="absolute right-0 top-0">
                <button
                  type="button"
                  className="-m-2 inline-flex p-2 text-gray-400 hover:text-gray-500"
                  onClick={handleRemoveItem}
                >
                  <TrashIcon className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <p className="mt-4 flex space-x-2 text-sm text-gray-700">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
            aria-hidden="true"
            className="h-5 w-5 shrink-0 text-green-500"
          >
            <path
              fillRule="evenodd"
              d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z"
              clipRule="evenodd"
            ></path>
          </svg>
          <span>In stock</span>
        </p>
      </div>
    </li>
  );
};

export default CartItem;
