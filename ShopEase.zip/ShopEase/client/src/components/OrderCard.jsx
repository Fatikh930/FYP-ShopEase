import React, { useState, useEffect } from "react";
import axios from "axios";

const OrderCard = ({ order }) => {
  const [status, setStatus] = useState(order.status);

  const handleStatusChange = async (newStatus) => {
    try {
      await axios.put(`/api/orders/update-order-status/${order._id}`, {
        status: newStatus,
      });
      setStatus(newStatus);
      console.log("Order status updated successfully", status);
    } catch (error) {
      console.error(error);
      console.log("Order status not updated successfully", status);
    }
  };

  useEffect(() => {
    console.log("Order data:", order); // Log the order data for debugging
  }, [order]);

  return (
    <div className="rounded-2xl bg-white shadow-md p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Order Details
      </h2>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm font-bold text-gray-600">Name</p>
          <p className="text-sm text-gray-800">{order.user.fullName}</p>
        </div>

        <div>
          <p className="text-sm font-bold text-gray-600">Date</p>
          <p className="text-sm text-gray-800">
            {order.createdAt.substring(0, 10)}
          </p>
        </div>
        <div>
          <p className="text-sm font-bold text-gray-600">Total Price</p>
          <p className="text-sm text-gray-800">PKR {order.orderTotal}</p>
        </div>
        <div>
          <p className="text-sm font-bold text-gray-600">Status</p>
          <p className="text-sm text-red-500">{status}</p>
        </div>
      </div>
      <h3 className="text-sm font-bold text-gray-600 mt-4">Items:</h3>
      <ul className="text-sm text-gray-800 ml-4">
        {order.orderItems.map((item) => (
          <li key={item._id}>
            {item.product.name} ({item.quantity})
          </li>
        ))}
      </ul>
      <div className="flex justify-center mt-4">
        {status === "Pending" && (
          <button
            onClick={() => handleStatusChange("Shipped")}
            className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
          >
            Mark as Shipping
          </button>
        )}
        {status === "Shipped" && (
          <button
            onClick={() => handleStatusChange("Delivered")}
            className="mt-2 px-4 py-2 bg-green-500 text-white rounded"
          >
            Mark as Delivered
          </button>
        )}
      </div>
    </div>
  );
};

export default OrderCard;
