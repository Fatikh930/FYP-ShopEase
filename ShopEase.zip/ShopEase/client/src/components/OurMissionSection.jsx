import React from "react";

const OurMissionSection = () => {
  return (
    <div className="mx-auto -mt-12 max-w-7xl px-6 sm:mt-0 lg:px-8 xl:-mt-8">
      <div className="mx-auto max-w-2xl lg:mx-0 lg:max-w-none">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
          Our mission
        </h2>
        <div className="mt-6 flex flex-col gap-x-8 gap-y-20 lg:flex-row">
          <div className="w-full lg:max-w-2xl lg:flex-auto">
            <p className="text-xl leading-8 text-gray-600">
              At Shopease, our mission is to revolutionize the fashion
              experience by offering a thoughtfully curated selection of stylish
              and quality products. We aim to make fashion accessible to all,
              ensuring that elegance and affordability coexist harmoniously.
              We're dedicated to providing a diverse range of fashion items that
              cater to the unique tastes and preferences of our customers.
            </p>
            <div className="mt-10 max-w-xl text-base leading-7 text-gray-700">
              <p>
                In this project, we aim to redefine the online fashion retail
                experience by integrating advanced augmented reality (AR)
                technology into our website. By seamlessly blending the digital
                and physical realms, our goal is to offer users an immersive
                shopping journey that goes beyond conventional online browsing.
                Through AR, customers will have the ability to visualize how
                various products such as caps, glasses, rings, watches,
                necklaces, and shoes appear and fit in real-time, directly
                within their own surroundings.
              </p>
              <p className="mt-10">
                Our vision is to establish a new benchmark in online fashion
                retailing by harnessing the capabilities of AR to create a
                dynamic and interactive platform that delivers unparalleled
                convenience and customer delight.
              </p>
            </div>
          </div>
          <div className="lg:flex lg:flex-auto lg:justify-center">
            <dl className="w-64 space-y-[2rem] xl:w-80">
              <div className="flex flex-col-reverse gap-y-4">
                <dt className="text-base leading-7 text-gray-600">
                  Products categories available
                </dt>
                <dd className="text-5xl font-semibold tracking-tight text-gray-900">
                  6+
                </dd>
              </div>
              <div className="flex flex-col-reverse gap-y-4">
                <dt className="text-base leading-7 text-gray-600">
                  Total items
                </dt>
                <dd className="text-5xl font-semibold tracking-tight text-gray-900">
                  500+
                </dd>
              </div>
              <div className="flex flex-col-reverse gap-y-4">
                <dt className="text-base leading-7 text-gray-600">
                  New arrivals weekly
                </dt>
                <dd className="text-5xl font-semibold tracking-tight text-gray-900">
                  50+
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OurMissionSection;
