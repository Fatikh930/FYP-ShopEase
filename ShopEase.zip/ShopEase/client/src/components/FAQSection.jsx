import React from "react";
import { Link } from "react-router-dom";

const FAQSection = () => {
  return (
    <section className="px-6 md:mx-auto max-w-[90rem] py-10 lg:px-0">
      <div>
        <div className="mx-auto max-w-4xl lg:text-center">
          <h2 className="text-3xl font-bold leading-10 text-black sm:text-4xl lg:text-5xl">
            Frequently Asked Questions
          </h2>
        </div>
        <div className="mx-auto mt-8 grid max-w-4xl grid-cols-1 gap-6 lg:mt-16 lg:grid-cols-2">
          <div>
            <h2 className="text-lg font-semibold text-black">
              How can I try on products virtually?
            </h2>
            <p className="mt-6 text-sm leading-6 tracking-wide text-gray-500">
              Trying on products virtually is easy. Simply choose the product
              you're interested in, click the "Try on" button, and follow the
              step-by-step instructions provided on the screen. You'll be able
              to see how the product looks on you without physically trying it
            </p>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-black">
              Which products are available for virtual try-on?
            </h2>
            <p className="mt-6 text-sm leading-6 tracking-wide text-gray-500">
              Our virtual try-on feature covers a broad selection of fashion
              items, including shoes, glasses, caps, and watches. You can
              experiment with different styles and see how they complement your
              look.
            </p>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-black">
              Do I need any special devices or software to try products online?
            </h2>
            <p className="mt-6 text-sm leading-6 tracking-wide text-gray-500">
              No, there's no need for any special equipment or software
              installations. Our virtual try-on feature is accessible through
              your web browser on both desktop computers and mobile devices.
              Just visit our website, select a product, and start trying it on
              virtually.
            </p>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-black">
              Can I use the virtual try-on feature on my smartphone or tablet?
            </h2>
            <p className="mt-6 text-sm leading-6 tracking-wide text-gray-500">
              Absolutely! Our virtual try-on feature is fully compatible with
              smartphones and tablets. Whether you're on the go or at home, you
              can use your mobile device to experience the convenience of
              virtual try-ons.
            </p>
          </div>
        </div>
        <p className="mt-10 text-center text-gray-600">
          Can&#x27;t find what you&#x27;re looking for?{" "}
          <Link
            to="/contact"
            title=""
            className="black font-semibold hover:underline"
          >
            Contact us
          </Link>
        </p>
      </div>
    </section>
  );
};

export default FAQSection;
