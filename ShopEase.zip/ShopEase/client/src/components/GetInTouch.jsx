import React from "react";

const GetInTouch = () => {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl space-y-[4rem] divide-y-[1px] divide-gray-100 lg:mx-0 lg:max-w-none">
          <div className="grid grid-cols-1 gap-x-8 gap-y-10 lg:grid-cols-3">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                Get in touch
              </h2>
              <p className="mt-4 leading-7 text-gray-600">
                Contact us anytime for prompt assistance and support.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:col-span-2 lg:gap-8">
              <div className="rounded-2xl bg-gray-50 p-10">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                  Fatikh Khan
                </h3>
                <dl className="mt-3 space-y-[0.25rem] text-sm leading-6 text-gray-600">
                  <div>
                    <dd>
                      <a
                        className="font-semibold text-blue-500"
                        href="mailto:fatikh@example.com"
                      >
                        fatikh@example.com
                      </a>
                    </dd>
                  </div>
                  <div className="mt-1">
                    <dd>+92 300 456 7890</dd>
                  </div>
                </dl>
              </div>
              <div className="rounded-2xl bg-gray-50 p-10">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                  Fawad Ahmad
                </h3>
                <dl className="mt-3 space-y-[0.25rem] text-sm leading-6 text-gray-600">
                  <div>
                    <dd>
                      <a
                        className="font-semibold text-blue-500"
                        href="mailto:fawad@example.com"
                      >
                        fawad@example.com
                      </a>
                    </dd>
                  </div>
                  <div className="mt-1">
                    <dd>+92 300 012 3456</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-x-8 gap-y-10 pt-16 lg:grid-cols-3">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                Locations
              </h2>
              <p className="mt-4 leading-7 text-gray-600">
                Explore convenient access to our various locations for
                exceptional service.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:col-span-2 lg:gap-8">
              <div className="rounded-2xl bg-gray-50 p-10">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                  Attock
                </h3>
                <address className="mt-3 space-y-[0.25rem] text-sm not-italic leading-6 text-gray-600">
                  <p>Comsats Attock Campus</p>
                  <p>Punjab Pakistan</p>
                </address>
              </div>
              <div className="rounded-2xl bg-gray-50 p-10">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                  Waisa
                </h3>
                <address className="mt-3 space-y-[0.25rem] text-sm not-italic leading-6 text-gray-600">
                  <p>Waisa, Attock</p>
                  <p>Punjab, Pakistan</p>
                </address>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetInTouch;
