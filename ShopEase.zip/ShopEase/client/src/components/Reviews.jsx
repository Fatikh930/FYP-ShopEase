import React from "react";
import { StarIcon } from "@heroicons/react/24/solid";

const Reviews = ({ reviews }) => {
  return (
    <div className="bg-white">
      <h2 className="font-bold text-3xl text-center">Customer Reviews</h2>
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-24">
        <div className="bg-white">
          {reviews.length > 0 ? (
            reviews.map((review) => (
              <div key={review._id} className="-my-9">
                <div className="flex space-x-3 text-sm text-gray-500">
                  <div className="flex-none py-9">
                    <img
                      src={review.user.avatar || "default-profile-image-url"}
                      alt={review.user.fullName}
                      className="h-10 w-10 rounded-full bg-gray-100"
                    />
                  </div>
                  <div className="flex-1 py-9">
                    <h3 className="font-medium text-gray-900">
                      {review.user.fullName}
                    </h3>
                    <p>
                      <time dateTime={review.reviewDate}>
                        {new Date(review.reviewDate).toLocaleDateString()}
                      </time>
                    </p>
                    <div className="mt-4 flex items-center">
                      {[...Array(5)].map((_, index) => (
                        <StarIcon
                          key={index}
                          className={`h-5 w-5 shrink-0 ${
                            index < review.rating
                              ? "text-yellow-400"
                              : "text-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                    <div className="p text-sm mt-4 max-w-none text-gray-500">
                      <p>{review.comment}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-gray-500">
              No reviews yet. Be the first to review this product!
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Reviews;
