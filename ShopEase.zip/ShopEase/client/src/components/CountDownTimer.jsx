import React, { useEffect, useState } from "react";

const CountDownTimer = () => {
  const [days, setDays] = useState(0);
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);

  // Set the target date and time for the countdown (e.g., 10 days from now)
  const targetTime = new Date().getTime() + 5 * 24 * 60 * 60 * 1000;

  useEffect(() => {
    const intervalId = setInterval(() => {
      const currentTime = new Date().getTime();
      const timeDifference = targetTime - currentTime;

      if (timeDifference <= 0) {
        setDays(0);
        setHours(0);
        setMinutes(0);
        setSeconds(0);
        clearInterval(intervalId);
        return;
      }

      setDays(Math.floor(timeDifference / (1000 * 60 * 60 * 24)));
      setHours(
        Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      );
      setMinutes(Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60)));
      setSeconds(Math.floor((timeDifference % (1000 * 60)) / 1000));
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex justify-start items-center space-x-2">
      <div className="w-20 flex flex-col items-center bg-gray-100 rounded-lg p-4 text-blue-500">
        <p className="text-3xl font-semibold">{days}</p>
        <p className="text-sm">Days</p>
      </div>
      <div className="w-20 flex flex-col items-center bg-gray-100 rounded-lg p-4 text-blue-500">
        <p className="text-3xl font-semibold">{hours}</p>
        <p className="text-sm">Hours</p>
      </div>
      <div className="w-20 flex flex-col items-center bg-gray-100 rounded-lg p-4 text-blue-500">
        <p className="text-3xl font-semibold">{minutes}</p>
        <p className="text-sm">Minutes</p>
      </div>
      <div className="w-20 flex flex-col items-center bg-gray-100 rounded-lg p-4 text-blue-500">
        <p className="text-3xl font-semibold">{seconds}</p>
        <p className="text-sm">Seconds</p>
      </div>
    </div>
  );
};

export default CountDownTimer;
