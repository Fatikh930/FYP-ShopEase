import React, { useState } from "react";
import { RadioGroup } from "@headlessui/react";
import { CheckCircleIcon } from "@heroicons/react/20/solid";
import { CheckoutItem } from "../components";

const CheckoutForm = () => {
  const [selectedPaymentType, setSelectedPaymentType] = useState("credit-card");
  return (
    <div>
      <div>
        <h2 className="text-lg font-medium text-gray-900">
          Contact information
        </h2>
        <div className="mt-4">
          <label
            htmlFor="email-address"
            className="block text-sm font-medium text-gray-700"
          >
            Email address
          </label>
          <div className="mt-1">
            <input
              type="email"
              id="email-address"
              name="email-address"
              autoComplete="email"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
            />
          </div>
        </div>
      </div>
      <div className="mt-10 border-t border-gray-200 pt-10">
        <h2 className="text-lg font-medium text-gray-900">
          Shipping information
        </h2>
        <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
          <div>
            <label
              htmlFor="first-name"
              className="block text-sm font-medium text-gray-700"
            >
              First name
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="first-name"
                name="first-name"
                autoComplete="given-name"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label
              htmlFor="last-name"
              className="block text-sm font-medium text-gray-700"
            >
              Last name
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="last-name"
                name="last-name"
                autoComplete="family-name"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label
              htmlFor="company"
              className="block text-sm font-medium text-gray-700"
            >
              Company
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="company"
                id="company"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label
              htmlFor="address"
              className="block text-sm font-medium text-gray-700"
            >
              Address
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="address"
                id="address"
                autoComplete="street-address"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label
              htmlFor="apartment"
              className="block text-sm font-medium text-gray-700"
            >
              Apartment, suite, etc.
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="apartment"
                id="apartment"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label
              htmlFor="city"
              className="block text-sm font-medium text-gray-700"
            >
              City
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="city"
                id="city"
                autoComplete="address-level2"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label
              htmlFor="country"
              className="block text-sm font-medium text-gray-700"
            >
              Country
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="country"
                id="country"
                autoComplete="country-name"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="region"
              className="block text-sm font-medium text-gray-700"
            >
              State / Province
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="region"
                id="region"
                autoComplete="address-level1"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label
              htmlFor="postal-code"
              className="block text-sm font-medium text-gray-700"
            >
              Postal code
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="postal-code"
                id="postal-code"
                autoComplete="postal-code"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label
              htmlFor="phone"
              className="block text-sm font-medium text-gray-700"
            >
              Phone
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="phone"
                id="phone"
                autoComplete="tel"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="mt-10 border-t border-gray-200 pt-10">
        <RadioGroup>
          <RadioGroup.Label className="text-lg font-medium text-gray-900">
            Delivery method
          </RadioGroup.Label>
          <div
            className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4"
            role="none"
          >
            <RadioGroup.Option
              className="border-gray-300 relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm  focus:outline-none"
              value="standard"
            >
              {({ checked }) => (
                <>
                  <span className="flex flex-1">
                    <span className="flex flex-col">
                      <span className="block text-sm font-medium text-gray-900">
                        Standard
                      </span>
                      <span className="mt-1 flex items-center text-sm text-gray-500">
                        4–10 business days
                      </span>
                      <span className="mt-6 text-sm font-medium text-gray-900">
                        $5.00
                      </span>
                    </span>
                  </span>
                  {checked && (
                    <>
                      <CheckCircleIcon className="h-5 w-5 text-blue-500" />
                      <span
                        className="border-2 border-blue-400 pointer-events-none absolute -inset-px rounded-lg"
                        aria-hidden="true"
                      ></span>
                    </>
                  )}
                </>
              )}
            </RadioGroup.Option>

            <RadioGroup.Option
              className="border-gray-300 relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none"
              value="express"
            >
              {({ checked }) => (
                <>
                  <span className="flex flex-1">
                    <span className="flex flex-col">
                      <span className="block text-sm font-medium text-gray-900">
                        Express
                      </span>
                      <span className="mt-1 flex items-center text-sm text-gray-500">
                        2–5 business days
                      </span>
                      <span className="mt-6 text-sm font-medium text-gray-900">
                        $16.00
                      </span>
                    </span>
                  </span>
                  {checked && (
                    <>
                      <CheckCircleIcon className="h-5 w-5 text-blue-500" />
                      <span
                        className="border-2 border-blue-400 pointer-events-none absolute -inset-px rounded-lg"
                        aria-hidden="true"
                      ></span>
                    </>
                  )}
                </>
              )}
            </RadioGroup.Option>
          </div>
        </RadioGroup>
      </div>
      <div className="mt-10 border-t border-gray-200 pt-10">
        <h2 className="text-lg font-medium text-gray-900">Payment</h2>
        <fieldset className="mt-4">
          <legend className="sr-only">Payment type</legend>
          <RadioGroup
            value={selectedPaymentType}
            onChange={setSelectedPaymentType}
          >
            <div className="space-y-4 sm:flex sm:items-center sm:space-x-10 sm:space-y-0">
              <div className="flex items-center">
                <RadioGroup.Label className="sr-only">
                  Credit card
                </RadioGroup.Label>
                <RadioGroup.Option
                  value="credit-card"
                  className="flex items-center"
                >
                  {({ checked }) => (
                    <>
                      <input
                        id="credit-card"
                        name="payment-type"
                        type="radio"
                        className="h-4 w-4 border-gray-300 text-blue-500 focus:ring-blue-400"
                      />
                      <label
                        htmlFor="credit-card"
                        className="ml-3 block text-sm font-medium text-gray-700"
                      >
                        Credit card
                      </label>
                    </>
                  )}
                </RadioGroup.Option>
              </div>
              <div className="flex items-center">
                <RadioGroup.Label className="sr-only">PayPal</RadioGroup.Label>
                <RadioGroup.Option value="paypal" className="flex items-center">
                  {({ checked }) => (
                    <>
                      <input
                        id="paypal"
                        name="payment-type"
                        type="radio"
                        className="h-4 w-4 border-gray-300 text-blue-500 focus:ring-blue-400"
                      />
                      <label
                        htmlFor="paypal"
                        className="ml-3 block text-sm font-medium text-gray-700"
                      >
                        PayPal
                      </label>
                    </>
                  )}
                </RadioGroup.Option>
              </div>
              <div className="flex items-center">
                <RadioGroup.Label className="sr-only">
                  eTransfer
                </RadioGroup.Label>
                <RadioGroup.Option
                  value="etransfer"
                  className="flex items-center"
                >
                  {({ checked }) => (
                    <>
                      <input
                        id="etransfer"
                        name="payment-type"
                        type="radio"
                        className="h-4 w-4 border-gray-300 text-blue-500 focus:ring-blue-400"
                      />
                      <label
                        htmlFor="etransfer"
                        className="ml-3 block text-sm font-medium text-gray-700"
                      >
                        eTransfer
                      </label>
                    </>
                  )}
                </RadioGroup.Option>
              </div>
            </div>
          </RadioGroup>
        </fieldset>
        <div className="mt-6 grid grid-cols-4 gap-x-4 gap-y-6">
          <div className="col-span-4">
            <label
              htmlFor="card-number"
              className="block text-sm font-medium text-gray-700"
            >
              Card number
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="card-number"
                name="card-number"
                autoComplete="cc-number"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="col-span-4">
            <label
              htmlFor="name-on-card"
              className="block text-sm font-medium text-gray-700"
            >
              Name on card
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="name-on-card"
                name="name-on-card"
                autoComplete="cc-name"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div className="col-span-3">
            <label
              htmlFor="expiration-date"
              className="block text-sm font-medium text-gray-700"
            >
              Expiration date (MM/YY)
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="expiration-date"
                id="expiration-date"
                autoComplete="cc-exp"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label
              htmlFor="cvc"
              className="block text-sm font-medium text-gray-700"
            >
              CVC
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="cvc"
                id="cvc"
                autoComplete="csc"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-400 focus:ring-blue-400 sm:text-sm"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutForm;
