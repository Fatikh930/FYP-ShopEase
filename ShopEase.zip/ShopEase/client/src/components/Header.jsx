import { Fragment, useState, useEffect } from "react";
import { Dialog, Menu, Popover, Transition } from "@headlessui/react";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { ShoppingBagIcon, HeartIcon } from "@heroicons/react/20/solid";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { logo_primary } from "../assets";
import axios from "axios";
import useAuth from "../Hooks/AuthHook";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function Header() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { isAuthenticated, logoutUser } = useAuth();

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const response = await axios.get("/api/users/get-current-user", {
          withCredentials: true,
        });
        setUser(response.data.message);
        console.log("user response", response.data.message);
        console.log("user avatar", response.data.message.avatar);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to fetch user");
        if (err.response?.status === 401) {
          navigate("/login");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchCurrentUser();
  }, []);

  // console.log(user.avatar);

  return (
    <header className="bg-transparent z-30 relative">
      {/* Desktop navigation */}
      <nav
        className="mx-auto flex max-w-[90rem] items-center justify-between p-6 lg:px-8"
        aria-label="Global"
      >
        {/* Logo */}
        <div className="flex lg:flex-1">
          <Link
            to="/"
            className={`${
              mobileMenuOpen ? "hidden sm:block" : "block"
            } -m-1.5 p-1.5`}
          >
            <img className="h-5 w-auto" src={logo_primary} alt="" />
          </Link>
        </div>

        {/* Mobile Menu button */}
        <div className="flex lg:hidden">
          <button
            type="button"
            className={`${
              mobileMenuOpen ? "hidden" : "block"
            } -m-2.5 inline-flex. items-center justify-center rounded-md p-2.5 text-gray-700`}
            onClick={() => setMobileMenuOpen(true)}
          >
            <Bars3Icon className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>

        {/* Desktop Navigation */}
        <Popover.Group className="hidden lg:flex lg:gap-x-12">
          <NavLink
            to="/"
            className={({ isActive }) =>
              ` ${
                isActive
                  ? "underline underline-offset-8 decoration-4 decoration-blue-500  text-blue-500"
                  : "text-gray-900 hover:text-blue-600"
              } text-sm font-semibold leading-6 transition duration-300`
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/about"
            className={({ isActive }) =>
              ` ${
                isActive
                  ? "underline underline-offset-8 decoration-4 decoration-blue-500  text-blue-500"
                  : "text-gray-900 hover:text-blue-600"
              } text-sm font-semibold leading-6 transition duration-300`
            }
          >
            About
          </NavLink>

          <NavLink
            to="/products"
            className={({ isActive }) =>
              ` ${
                isActive
                  ? "underline underline-offset-8 decoration-4 decoration-blue-500  text-blue-500"
                  : "text-gray-900 hover:text-blue-600"
              } text-sm font-semibold leading-6 transition duration-300`
            }
          >
            Products
          </NavLink>

          <NavLink
            to="/contact"
            className={({ isActive }) =>
              ` ${
                isActive
                  ? "underline underline-offset-8 decoration-4 decoration-blue-500  text-blue-500"
                  : "text-gray-900 hover:text-blue-600"
              } text-sm font-semibold leading-6 transition duration-300`
            }
          >
            Contact
          </NavLink>
          <NavLink
            to="/userprofile"
            className={({ isActive }) =>
              ` ${
                isActive
                  ? "underline underline-offset-8 decoration-4 decoration-blue-500  text-blue-500"
                  : "text-gray-900 hover:text-blue-600"
              } text-sm font-semibold leading-6 transition duration-300`
            }
          >
            Profile
          </NavLink>
        </Popover.Group>

        {/* Login and Sign up Section */}
        <div
          className={`${
            isAuthenticated
              ? "hidden"
              : "hidden lg:flex lg:flex-1 lg:justify-end lg:items-center lg:gap-x-4"
          }`}
        >
          <Link
            to="/login"
            className="text-sm font-semibold leading-6 text-gray-900 hover:text-blue-500"
          >
            Log in
          </Link>
          <Link
            to="/signup"
            className="text-sm font-semibold leading-6 rounded-md bg-blue-500 hover:bg-blue-600 px-3 py-2 text-white shadow-sm"
          >
            Sign up
          </Link>
        </div>
        <div
          className={`${
            isAuthenticated
              ? "hidden lg:flex lg:flex-1 lg:justify-end lg:items-center lg:gap-x-4"
              : "hidden"
          }`}
        >
          <Link
            to="/cart"
            className="relative rounded-full bg-blue-500 p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-500"
          >
            <span className="absolute -inset-1.5" />
            <span className="sr-only">View notifications</span>
            <ShoppingBagIcon
              className="h-6 w-6 text-white"
              aria-hidden="true"
            />
          </Link>
          <Link
            to="/wishlist"
            className="relative rounded-full bg-blue-500 p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-500"
          >
            <span className="absolute -inset-1.5" />
            <HeartIcon className="h-6 w-6 text-white" aria-hidden="true" />
          </Link>
          <button
            className="text-sm font-semibold leading-6 rounded-md bg-blue-500 hover:bg-blue-600 px-3 py-2 text-white shadow-sm"
            onClick={logoutUser}
          >
            Logout
          </button>
        </div>
      </nav>

      {/* Mobile menu, show/hide based on menu state. */}
      <Dialog
        as="div"
        className="lg:hidden"
        open={mobileMenuOpen}
        onClose={setMobileMenuOpen}
      >
        <div className="fixed inset-0 z-10" />
        <Dialog.Panel className="fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
          <div className="flex items-center justify-between">
            <Link to="/" className="-m-1.5 p-1.5">
              <img className="h-5 w-auto" src={logo_primary} alt="" />
            </Link>
            <button
              type="button"
              className="-m-2.5 rounded-md p-2.5 text-gray-700 justify-self-end"
              onClick={() => setMobileMenuOpen(false)}
            >
              <XMarkIcon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          <div className="mt-6 flow-root">
            <div className="-my-6 divide-y divide-gray-500/10">
              <div className="space-y-2 py-6">
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    ` ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : "text-gray-900 hover:bg-gray-50"
                    } -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  `
                  }
                >
                  Home
                </NavLink>
                <NavLink
                  to="/about"
                  className={({ isActive }) =>
                    ` ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : "text-gray-900 hover:bg-gray-50"
                    } -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  `
                  }
                >
                  About
                </NavLink>
                <NavLink
                  to="/products"
                  className={({ isActive }) =>
                    ` ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : "text-gray-900 hover:bg-gray-50"
                    } -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  `
                  }
                >
                  Products
                </NavLink>
                <NavLink
                  to="/contact"
                  className={({ isActive }) =>
                    ` ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : "text-gray-900 hover:bg-gray-50"
                    } -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  `
                  }
                >
                  Contact
                </NavLink>
                <NavLink
                  to="/userprofile"
                  className={({ isActive }) =>
                    ` ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : "text-gray-900 hover:bg-gray-50"
                    } -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7  `
                  }
                >
                  Profile
                </NavLink>
              </div>
              <div className="py-6">
                <div className={`${isAuthenticated ? "hidden" : ""}`}>
                  <Link
                    to="/login"
                    className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Log in
                  </Link>
                  <Link
                    to="/signup"
                    className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Sign up
                  </Link>
                </div>
                <div>
                  <div
                    className={`${
                      isAuthenticated
                        ? "flex justify-around lg:hidden"
                        : "hidden"
                    }`}
                  >
                    <Link
                      to="/cart"
                      className="relative rounded-full bg-blue-500 p-2 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-500"
                    >
                      <span className="absolute -inset-1.5" />
                      <span className="sr-only">View notifications</span>
                      <ShoppingBagIcon
                        className="h-6 w-6 text-white"
                        aria-hidden="true"
                      />
                    </Link>

                    <Link
                      to="/wishlist"
                      className="relative rounded-full bg-blue-500 p-2 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-500"
                    >
                      <span className="absolute -inset-1.5" />
                      <span className="sr-only">View notifications</span>
                      <HeartIcon
                        className="h-6 w-6 text-white"
                        aria-hidden="true"
                      />
                    </Link>

                    <button
                      to="/"
                      className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                      onClick={logoutUser}
                    >
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Dialog.Panel>
      </Dialog>
    </header>
  );
}
