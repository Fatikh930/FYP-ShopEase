import { CountDownTimer } from "../components";
import { Link } from "react-router-dom";
import products from "./AllProducts";
import React, { useState, Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, OrbitControls } from "@react-three/drei";
import Sun_glasses from "../../public/Sun_glasses";

const DealSection = () => {
  const product = products.find((product) => product.deal);

  return (
    <div className="relative md:w-screen. w-full md:h-screen">
      <div
        className="absolute top-48 inset-x-0 -z-10 transform-gpu blur-[160px] overflow-hidden"
        aria-hidden="true"
      >
        <div
          className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[50rem] sm:w-[110rem] md:w-[110rem] xl:w-[150rem] h-[90rem] md:h-[45rem] xl:h-[65rem] -translate-x-1/2 rotate-[0deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%-30rem)] "
          style={{
            clipPath:
              "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
          }}
        ></div>
      </div>
      <div className="flex flex-col lg:flex-row justify-evenly gap-3 lg:gap-0 p-4 lg:p-8 xl:p-16 m-6 lg:m-3 lg:w-[56rem] xl:w-[68rem] rounded-xl shadow-xl lg:absolute lg:top-1/2 lg:left-1/2 lg:transform lg:-translate-x-1/2 lg:-translate-y-1/2 bg-white">
        <div className="flex flex-col mx-auto justify-between">
          <div>
            <p className="tracking-[0.5rem] md:tracking-[0.3rem] lg:tracking-[0.5rem] uppercase text-center lg:text-start">
              Weekend Offer
            </p>
            <h2 className="uppercase font-sans font-black md:font-extrabold lg:font-black mt-4 text-[4rem] md:text-[3rem] lg:text-[4rem] xl:text-[5rem] leading-none text-blue-500 text-center lg:text-start">
              Special Offer
            </h2>
          </div>
          <h2 className="font-black md:font-extrabold lg:font-black text-[4rem] md:text-[3rem] lg:text-[4rem] xl:text-[5rem] font-['Arial'] text-center lg:text-start">
            -30%
          </h2>
          <CountDownTimer />
          <Link
            to={`/product/${product.id}`}
            className="text-center lg:text-start"
          >
            <button className="rounded-md bg-blue-500 hover:bg-blue-600 mt-8 py-3 px-6 font-semibold text-sm text-white">
              Shop Now
            </button>
          </Link>
        </div>
        <div className="md:w-[44rem] lg:w-[22rem] xl:w-[28rem]">
          <Canvas>
            <ambientLight intensity={3} />
            <OrbitControls />
            <Suspense fallback={null}>
              <Sun_glasses />
            </Suspense>
            <Environment preset="sunset" />
          </Canvas>
        </div>
      </div>
    </div>
  );
};

export default DealSection;
