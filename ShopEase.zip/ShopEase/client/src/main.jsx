import React from "react";
import ReactDOM from "react-dom/client";
import { Provider } from "react-redux";
import { store } from "./app/store.js";
import "./index.css";
import {
  Route,
  RouterProvider,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import Layout from "./layout/Layout.jsx";
import {
  Home,
  About,
  Contact,
  Products,
  ErrorPage,
  LoginPage,
  SignupPage,
  CartPage,
  SingleProduct,
  ARPage,
  AdminOrders,
  AdminCustomer,
  AdminProducts,
  AdminTeam,
  Success,
  Cancelled,
  UserProfile,
  AdminLogin,
  WishlistPage,
} from "./pages";

const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route path="/" element={<Layout />} errorElement={<ErrorPage />}>
        <Route path="" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
        <Route path="products" element={<Products />} />
        <Route path="product/:id" element={<SingleProduct />} />
        <Route path="/userprofile" element={<UserProfile />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/success" element={<Success />} />
        <Route path="/cancel" element={<Cancelled />} />
        <Route path="/wishlist" element={<WishlistPage />} />
      </Route>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />
      <Route path="/arpage/:id" element={<ARPage />} />
      <Route path="/admin/orders" element={<AdminOrders />} />
      <Route path="/admin/customers" element={<AdminCustomer />} />
      <Route path="/admin/products" element={<AdminProducts />} />
      <Route path="/admin/team" element={<AdminTeam />} />
      <Route path="/admin/login" element={<AdminLogin />} />
    </>
  )
);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Provider store={store}>
      <RouterProvider router={router} />
    </Provider>
  </React.StrictMode>
);
