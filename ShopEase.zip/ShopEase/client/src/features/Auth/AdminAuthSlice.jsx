import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isAuthenticated: false,
  admin: null,
};

const adminAuthSlice = createSlice({
  name: "adminAuth",
  initialState,
  reducers: {
    login: (state, action) => {
      state.isAuthenticated = true;
      state.admin = action.payload;
    },
    logout: (state) => {
      state.isAuthenticated = false;
      state.admin = null;
    },
  },
});

export const { login, logout } = adminAuthSlice.actions;
export default adminAuthSlice.reducer;
