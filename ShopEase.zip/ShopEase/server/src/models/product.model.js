import mongoose, { Schema } from "mongoose";

const productSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    type: {
      type: String,
      enum: ["men", "women"],
      default: "men",
      required: true,
    },
    productImage: {
      type: String,
      required: true,
    },

    cameraType: {
      type: String,
      enum: ["front", "back"],
      required: true,
    },
    lensGroupId: {
      type: String,
      required: true,
    },
    lensNo: {
      type: Number,
      required: true,
    },
    lensId: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    reviews: [
      {
        user: {
          type: Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },
        title: String,
        rating: {
          type: Number,
          min: 1,
          max: 5,
          required: true,
        },
        comment: String,
        reviewDate: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  { timestamps: true }
);

export const Product = mongoose.model("Product", productSchema);
