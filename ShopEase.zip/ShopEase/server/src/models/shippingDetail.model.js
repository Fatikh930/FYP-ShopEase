import mongoose, { Schema } from "mongoose";

const shippingDetailSchema = new Schema(
  {
    order: {
      type: Schema.Types.ObjectId,
      ref: "Order",
      required: true,
    },
    address: String,
    carrier: String,
    shippingStatus: String,
    trackingNumber: String,
    estimatedDelivery: Date,
  },
  { timestamps: true }
);

export const ShippingDetail = mongoose.model(
  "ShippingDetail",
  shippingDetailSchema
);
