import mongoose from "mongoose";
import { DB_NAME } from "../constants.js";

/**
 * Asynchronous function to connect to the MongoDB database.
 * @async
 * @function
 * @throws {Error} When there is a connection error.
 */
const connectDB = async () => {
  try {
    // Create a connection instance using mongoose
    // const connectionInstance = await mongoose.connect(
    //   `${process.env.MONGODB_URI}/${DB_NAME}`
    // );
    const connectionInstance = await mongoose.connect(process.env.MONGODB_URI, {
      dbName: DB_NAME,
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    // Log the host to which MongoDB is connected
    console.log(`\n MongoDB connected: ${connectionInstance.connection.host}`);
  } catch (error) {
    // Log the error message to the console and exit the process with a status code of 1
    console.log("Mongodb connection error", error);
    process.exit(1);
  }
};

export default connectDB;
