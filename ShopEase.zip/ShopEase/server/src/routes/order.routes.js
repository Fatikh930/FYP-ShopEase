import { Router } from "express";
import {
  checkout,
  getOrders,
  updateOrderStatus,
} from "../controllers/order.controller.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

router.route("/create-checkout-session").post(verifyJWT, checkout);
router.route("/get-orders").get(getOrders);
router.route("/update-order-status/:id").put(updateOrderStatus);

export default router;
