import { Router } from "express";
import {
  createProduct,
  deleteProduct,
  updateProduct,
  addReview,
  getReviews,
  searchProducts,
  getProducts,
  getProductById,
} from "../controllers/product.controller.js";
import { upload } from "../middlewares/multer.middleware.js";

const router = Router();

router
  .route("/create-product")
  .post(upload.fields([{ name: "productImage", maxCount: 1 }]), createProduct);
router.route("/delete-product/:id").delete(deleteProduct);
router
  .route("/update-product/:id")
  .put(upload.fields([{ name: "productImage", maxCount: 1 }]), updateProduct);
router.route("/add-review/:id").post(addReview);
router.route("/get-reviews/:id").get(getReviews);
router.route("/search").get(searchProducts);
router.route("/get-products").get(getProducts);
router.route("/get-product/:id").get(getProductById);

export default router;
