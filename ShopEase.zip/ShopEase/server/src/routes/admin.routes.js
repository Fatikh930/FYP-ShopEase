import { Router } from "express";
import {
  registerAdmin,
  loginAdmin,
  logoutAdmin,
  refreshAccessToken,
  getAllAdmins,
  checkAuthAdmin,
} from "../controllers/admin.controller.js";
import { upload } from "../middlewares/multer.middleware.js";
import { verifyAdminJWT } from "../middlewares/adminAuth.middleware.js";

const router = Router();

router.route("/register").post(registerAdmin);
router.route("/login").post(loginAdmin);
router.route("/logout").post(verifyAdminJWT, logoutAdmin);
router.route("/refresh-token").post(refreshAccessToken);
router.route("/get-all-admins").get(getAllAdmins);
router.route("/check-auth").get(verifyAdminJWT, checkAuthAdmin);

export default router;
