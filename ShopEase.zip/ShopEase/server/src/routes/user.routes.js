import { Router } from "express";
import {
  loginUser,
  logoutUser,
  registerUser,
  refreshAccessToken,
  checkAuth,
  addToCart,
  getCartItems,
  removeFromCart,
  updateCartItemQuantity,
  addToWishlist,
  removeFromWishlist,
  getAllUsers,
  getCurrentUser,
  removeAllFromCart,
  updateUserAvatar,
  changeCurrentPassword,
  updateFullName,
  getWishlist,
} from "../controllers/user.controller.js";
import { upload } from "../middlewares/multer.middleware.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

router.route("/register").post(registerUser);

router.route("/login").post(loginUser);

router.route("/logout").post(verifyJWT, logoutUser);
router.route("/check-auth").post(verifyJWT, checkAuth);
router.route("/refresh-token").post(refreshAccessToken);
router.route("/add-to-cart").post(verifyJWT, addToCart);
router.route("/get-cart-items").get(verifyJWT, getCartItems);
router.route("/remove-from-cart").post(verifyJWT, removeFromCart);
router
  .route("/update-cart-item-quantity")
  .post(verifyJWT, updateCartItemQuantity);
router.route("/remove-all-from-cart").post(verifyJWT, removeAllFromCart);
router.route("/add-to-wishlist").post(verifyJWT, addToWishlist);
router.route("/remove-from-wishlist").post(verifyJWT, removeFromWishlist);
router.route("/get-wishlist").get(verifyJWT, getWishlist);
router.route("/get-all-users").get(getAllUsers);
router.route("/get-current-user").get(verifyJWT, getCurrentUser);
router
  .route("/update-user-avatar")
  .put(
    verifyJWT,
    upload.fields([{ name: "avatar", maxCount: 1 }]),
    updateUserAvatar
  );
router.route("/change-password").post(verifyJWT, changeCurrentPassword);
router.route("/update-full-name").put(verifyJWT, updateFullName);

export default router;
