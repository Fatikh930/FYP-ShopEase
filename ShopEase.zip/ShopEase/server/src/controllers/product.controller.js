import { Product } from "../models/product.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { uploadOnCloudinary } from "../utils/cloudinary.js";

const createProduct = asyncHandler(async (req, res) => {
  try {
    // Destructure the product details from the request body
    const {
      name,
      description,
      price,
      type,
      cameraType,
      lensGroupId,
      lensNo,
      lensId,
      category,
    } = req.body;

    // Validate required fields
    if (
      !name ||
      !description ||
      !price ||
      !type ||
      !cameraType ||
      !lensGroupId ||
      !lensNo ||
      !lensId ||
      !category
    ) {
      throw new ApiError(400, "All fields are required");
    }

    const productImageLocalPath = req.files?.productImage[0]?.path;
    if (!productImageLocalPath) {
      throw new ApiError(400, "Product image is required");
    }

    // Upload product image to Cloudinary
    const productImage = await uploadOnCloudinary(productImageLocalPath);
    if (!productImage) {
      throw new ApiError(500, "Failed to upload product image");
    }

    // Create the product instance
    const product = new Product({
      name,
      description,
      price,
      type,
      cameraType,
      lensGroupId,
      lensNo,
      lensId,
      category,
      productImage: productImage.url,
    });

    // Save the product to the database
    await product.save();

    // Respond with success message
    res.status(201).json({
      message: "Product created successfully",
      product,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const deleteProduct = asyncHandler(async (req, res) => {
  try {
    const productId = req.params.id;

    // Find the product by ID
    const product = await Product.findById(productId);
    if (!product) {
      throw new ApiError(404, "Product not found");
    }

    // Update the product to remove image URLs
    product.productImages = [];
    await product.save();

    // Delete the product from the database
    await Product.findByIdAndDelete(productId);

    // Respond with success message
    res.status(200).json({
      message: "Product deleted successfully",
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const updateProduct = asyncHandler(async (req, res) => {
  try {
    const productId = req.params.id;
    const {
      name,
      description,
      price,
      type,
      cameraType,
      lensGroupId,
      lensNo,
      lensId,
      category,
    } = req.body;

    // Find the product by ID
    const product = await Product.findById(productId);
    if (!product) {
      throw new ApiError(404, "Product not found");
    }

    // Update the product fields
    if (name) product.name = name;
    if (description) product.description = description;
    if (price) product.price = price;
    if (type) product.type = type;
    if (cameraType) product.cameraType = cameraType;
    if (lensGroupId) product.lensGroupId = lensGroupId;
    if (lensNo) product.lensNo = lensNo;
    if (lensId) product.lensId = lensId;
    if (category) product.category = category;

    // Check if a new product image file is provided
    const productImageLocalPath = req.files?.productImage[0]?.path;
    if (!productImageLocalPath) {
      throw new ApiError(400, "Product image is required");
    }

    // Upload product image to Cloudinary
    const productImage = await uploadOnCloudinary(productImageLocalPath);
    if (!productImage) {
      throw new ApiError(500, "Failed to upload product image");
    }

    // Update product image URL
    product.productImage = productImage.url;

    // Save the updated product to the database
    await product.save();

    // Respond with success message
    res.status(200).json({
      message: "Product updated successfully",
      product,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const addReview = asyncHandler(async (req, res) => {
  try {
    const productId = req.params.id;
    const { user, title, rating, comment } = req.body;

    // Find the product by ID
    const product = await Product.findById(productId);
    if (!product) {
      throw new ApiError(404, "Product not found");
    }

    // Create a new review object
    const newReview = {
      user,
      title,
      rating,
      comment,
    };

    // Add the review to the product's reviews array
    product.reviews.push(newReview);

    // Save the updated product to the database
    await product.save();

    // Respond with success message
    res.status(200).json({
      message: "Review added successfully",
      product,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getReviews = asyncHandler(async (req, res) => {
  const productId = req.params.id;

  try {
    const product = await Product.findById(productId).populate(
      "reviews.user",
      "fullName avatar"
    );

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.status(200).json({ reviews: product.reviews });
  } catch (error) {
    console.error("Error fetching reviews:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

const searchProducts = asyncHandler(async (req, res) => {
  try {
    const { name, category, minPrice, maxPrice } = req.query;

    // Build the search query based on the provided criteria
    let query = {};
    if (name) {
      query.name = { $regex: name, $options: "i" };
    }
    if (category) {
      query.category = { $regex: category, $options: "i" };
    }
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) {
        query.price.$gte = minPrice;
      }
      if (maxPrice) {
        query.price.$lte = maxPrice;
      }
    }

    // Find products that match the search query
    const products = await Product.find(query);

    // Respond with the search results
    res.status(200).json({
      message: "Search results",
      products,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getProducts = asyncHandler(async (req, res) => {
  try {
    // Find all products
    const products = await Product.find();

    // Respond with the products
    res.status(200).json({
      message: "All products",
      products,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getProductById = asyncHandler(async (req, res) => {
  try {
    const productId = req.params.id;

    // Find the product by ID
    const product = await Product.findById(productId);
    if (!product) {
      throw new ApiError(404, "Product not found");
    }

    // Respond with the product
    res.status(200).json({
      message: "Product found",
      product,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

export {
  createProduct,
  deleteProduct,
  updateProduct,
  addReview,
  searchProducts,
  getProducts,
  getProductById,
  getReviews,
};
