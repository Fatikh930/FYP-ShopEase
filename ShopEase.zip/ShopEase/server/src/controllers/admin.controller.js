import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { Admin } from "../models/admin.model.js";
import { uploadOnCloudinary } from "../utils/cloudinary.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const registerAdmin = asyncHandler(async (req, res) => {
  const { fullName, username, email, password } = req.body;

  if (
    [fullName, username, email, password].some((field) => field?.trim() === "")
  ) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const existingUsername = await Admin.findOne({
    $or: [{ username }],
  });

  if (existingUsername) {
    return res.status(400).json({ message: "Username already exists" });
  }

  const existingEmail = await Admin.findOne({
    $or: [{ email }],
  });

  if (existingEmail) {
    return res.status(400).json({ message: "Email already exists" });
  }

  const admin = await Admin.create({
    fullName,
    username: username.toLowerCase(),
    email,
    password,
  });

  const createdAdmin = await Admin.findById(admin._id).select(
    "-password -refreshToken"
  );

  if (!createdAdmin) {
    return res.status(500).json({ message: "Failed to create admin" });
  }

  return res
    .status(201)
    .json(new ApiResponse(200, createdAdmin, "Admin created successfully"));
});
const generateAccessAndRefreshTokens = async (adminId) => {
  try {
    const admin = await Admin.findById(adminId);
    const accessToken = admin.generateAccessToken();
    const refreshToken = admin.generateRefreshToken();

    admin.refreshToken = refreshToken;
    await admin.save({ validateBeforeSave: false });

    return { accessToken, refreshToken };
  } catch (error) {
    console.log(error);
    throw new ApiError(500, "Something went wrong while generating tokens");
  }
};

const loginAdmin = asyncHandler(async (req, res) => {
  const { username, password } = await req.body;

  if (!username || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const admin = await Admin.findOne({
    username: username.toLowerCase(),
  });

  if (!admin) {
    return res.status(404).json({ message: "Admin not found" });
  }

  const isPasswordValid = await admin.isPasswordCorrect(password);

  if (!isPasswordValid) {
    return res.status(401).json({ message: "Invalid password" });
  }

  const { accessToken, refreshToken } = await generateAccessAndRefreshTokens(
    admin._id
  );

  const loggedInAdmin = await Admin.findById(admin._id).select(
    "-password -refreshToken"
  );

  const options = {
    httpOnly: true,
    secure: true,
  };

  return res
    .status(200)
    .cookie("accessToken", accessToken, options)
    .cookie("refreshToken", refreshToken, options)
    .json(
      new ApiResponse(
        200,
        { admin: loggedInAdmin, accessToken, refreshToken },
        "Login successful"
      )
    );
});

const logoutAdmin = asyncHandler(async (req, res) => {
  await Admin.findByIdAndUpdate(
    req.admin._id,
    { $set: { refreshToken: undefined } },
    { new: true }
  );

  const options = {
    httpOnly: false,
    secure: false,
  };

  return res
    .status(200)
    .clearCookie("accessToken", options)
    .clearCookie("refreshToken", options)
    .json(new ApiResponse(200, {}, "Logout successful"));
});

const refreshAccessToken = asyncHandler(async (req, res) => {
  const incomingRefreshToken =
    req.cookies.refreshToken || req.body.refreshToken;

  if (!incomingRefreshToken) {
    throw new ApiError(401, "Unauthorized Request");
  }

  try {
    const decodedToken = jwt.verify(
      incomingRefreshToken,
      process.env.REFRESH_TOKEN_SECRET
    );

    const admin = await Admin.findById(decodedToken?._id);

    if (!admin) {
      throw new ApiError(401, "Invalid refresh token");
    }

    if (admin?.refreshToken !== incomingRefreshToken) {
      throw new ApiError(401, "Refresh token is expired or used");
    }

    const options = {
      httpOnly: true,
      secure: true,
    };

    const { accessToken, newRefreshToken } =
      await generateAccessAndRefreshTokens(admin._id);

    return res
      .status(200)
      .cookie("accessToken", accessToken, options)
      .cookie("refreshToken", newRefreshToken, options)
      .json(
        new ApiResponse(
          200,
          { accessToken, refreshToken: newRefreshToken },
          "Token refreshed successfully"
        )
      );
  } catch (error) {
    throw new ApiError(401, error?.message || "Invalid refresh token");
  }
});

const changeCurrentPassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const admin = await Admin.findById(req.admin?._id);
  const isPasswordCorrect = await admin.isPasswordCorrect(currentPassword);

  if (!isPasswordCorrect) {
    throw new ApiError(401, "Invalid current password");
  }

  admin.password = newPassword;
  await admin.save({ validateBeforeSave: false });

  return res.status(200).json(new ApiResponse(200, {}, "Password updated"));
});

const deleteAdmin = asyncHandler(async (req, res) => {
  // Extract the admin ID from the request parameters
  const adminId = req.params.id;

  try {
    // Find the admin document by ID and delete it
    const deletedAdmin = await Admin.findByIdAndDelete(adminId);

    if (!deletedAdmin) {
      // If no admin was found with the provided ID, return a 404 Not Found error
      return res.status(404).json({ message: "Admin not found" });
    }

    // If the admin was successfully deleted, return a success response
    return res.status(200).json({ message: "Admin deleted successfully" });
  } catch (error) {
    // Handle any errors that occur during the deletion process
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

const getAllAdmins = asyncHandler(async (req, res) => {
  try {
    // Fetch all admins from the database
    const admins = await Admin.find();

    // If no admins found, return an error
    if (!admins || admins.length === 0) {
      throw new ApiError(404, "No admins found");
    }

    // Respond with the list of admins
    res.status(200).json({
      message: "All admins",
      admins,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const checkAuthAdmin = asyncHandler(async (req, res) => {
  try {
    const admin = await Admin.findById(req.admin?._id).select("-password");
    if (!admin) {
      return res.status(401).json(new ApiResponse(401, {}, "Unauthorized"));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, admin, "Admin is Authenticated"));
  } catch (error) {
    return res.status(401).json(new ApiResponse(401, {}, "Unauthorized"));
  }
});

export {
  registerAdmin,
  loginAdmin,
  logoutAdmin,
  refreshAccessToken,
  changeCurrentPassword,
  deleteAdmin,
  getAllAdmins,
  checkAuthAdmin,
};
