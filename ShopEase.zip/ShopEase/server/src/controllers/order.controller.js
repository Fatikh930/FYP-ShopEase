import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { User } from "../models/user.model.js";
import { OrderItem } from "../models/orderItem.model.js";
import { Order } from "../models/order.model.js";
import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const checkout = asyncHandler(async (req, res) => {
  const { product, shippingData } = req.body;
  console.log(product);
  console.log(shippingData);

  // Create order items
  const orderItems = [];
  for (let i = 0; i < product.length; i++) {
    const item = await OrderItem.create({
      product: product[i]._id,
      quantity: product[i].quantity,
      price: product[i].price,
      itemTotal: product[i].price * product[i].quantity,
    });
    orderItems.push(item._id);
  }

  // Create order
  const order = await Order.create({
    user: req.user._id,
    orderItems: orderItems,
    shippingAddress: {
      address: shippingData.address,
      city: shippingData.city,
      country: shippingData.country,
      postalCode: shippingData.postalCode,
    },
    orderTotal: product.reduce((acc, cur) => acc + cur.price * cur.quantity, 0),
  });

  const lineItems = product.map((product) => ({
    price_data: {
      currency: "pkr",
      product_data: {
        name: product.name,
      },
      unit_amount: product.price * 100,
    },
    quantity: product.quantity,
  }));

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: lineItems,

    shipping_options: [
      {
        shipping_rate_data: {
          type: "fixed_amount",
          fixed_amount: {
            amount: 0,
            currency: "pkr",
          },
          display_name: "Free shipping",
          delivery_estimate: {
            minimum: {
              unit: "business_day",
              value: 5,
            },
            maximum: {
              unit: "business_day",
              value: 7,
            },
          },
        },
      },
      {
        shipping_rate_data: {
          type: "fixed_amount",
          fixed_amount: {
            amount: 15000,
            currency: "pkr",
          },
          display_name: "Next day air",
          delivery_estimate: {
            minimum: {
              unit: "business_day",
              value: 2,
            },
            maximum: {
              unit: "business_day",
              value: 3,
            },
          },
        },
      },
    ],
    mode: "payment",
    success_url: `${process.env.CLIENT_URL}/success`,
    cancel_url: `${process.env.CLIENT_URL}/cancel`,
  });

  const userId = req.user._id;
  const user = await User.findById(userId);
  if (!user) {
    throw new ApiError(404, "User not found");
  }
  user.cart = [];
  await user.save();

  res.json({ id: session.id });
});

const getOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({})
    .populate("user", "fullName email")
    .populate({
      path: "orderItems",
      populate: {
        path: "product",
        select: "name price",
      },
    });

  res.status(200).json(orders);
});

const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    order.status = req.body.status;
    console.log(order.status);
    await order.save();

    res.status(200).json({ message: "Order status updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

export { checkout, getOrders, updateOrderStatus };
