import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { User } from "../models/user.model.js";
import { uploadOnCloudinary } from "../utils/cloudinary.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const registerUser = asyncHandler(async (req, res) => {
  const { fullName, username, email, password } = req.body;

  if (
    [fullName, username, email, password].some((field) => field?.trim() === "")
  ) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const existingUsername = await User.findOne({
    $or: [{ username }],
  });

  if (existingUsername) {
    return res.status(400).json({ message: "Username already exists" });
  }

  const existingEmail = await User.findOne({
    $or: [{ email }],
  });

  if (existingEmail) {
    return res.status(400).json({ message: "Email already exists" });
  }

  const user = await User.create({
    fullName,
    username: username.toLowerCase(),
    email,
    password,
    avatar:
      "https://res.cloudinary.com/shopeasefyp/image/upload/v1716031851/user_m5vnlg.png",
  });

  const createdUser = await User.findById(user._id).select(
    "-password -refreshToken"
  );

  if (!createdUser) {
    return res.status(500).json({ message: "Failed to create user" });
  }

  return res
    .status(201)
    .json(new ApiResponse(200, createdUser, "User created successfully"));
});

const generateAccessAndRefreshTokens = async (userId) => {
  try {
    const user = await User.findById(userId);
    const accessToken = user.generateAccessToken();
    const refreshToken = user.generateRefreshToken();

    user.refreshToken = refreshToken;
    await user.save({ validateBeforeSave: false });

    return { accessToken, refreshToken };
  } catch (error) {
    console.log(error);
    throw new ApiError(500, "Something went wrong while generating tokens");
  }
};

const loginUser = asyncHandler(async (req, res) => {
  console.log(req.body);
  const { username, password } = await req.body;

  if (!username || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const user = await User.findOne({
    username: username.toLowerCase(),
  });

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  const isPasswordValid = await user.isPasswordCorrect(password);

  if (!isPasswordValid) {
    return res.status(401).json({ message: "Invalid password" });
  }

  const { accessToken, refreshToken } = await generateAccessAndRefreshTokens(
    user._id
  );

  const loggedInUser = await User.findById(user._id).select(
    "-password -refreshToken"
  );

  const options = {
    httpOnly: true,
    secure: true,
  };

  return res
    .status(200)
    .cookie("accessToken", accessToken, options)
    .cookie("refreshToken", refreshToken, options)
    .json(
      new ApiResponse(
        200,
        { user: loggedInUser, accessToken, refreshToken },
        "Login successful"
      )
    );
});

const logoutUser = asyncHandler(async (req, res) => {
  await User.findByIdAndUpdate(
    req.user._id,
    { $set: { refreshToken: undefined } },
    { new: true }
  );

  const options = {
    httpOnly: false,
    secure: false,
  };

  return res
    .status(200)
    .clearCookie("accessToken", options)
    .clearCookie("refreshToken", options)
    .json(new ApiResponse(200, {}, "Logout successful"));
});

const refreshAccessToken = asyncHandler(async (req, res) => {
  const incomingRefreshToken =
    req.cookies.refreshToken || req.body.refreshToken;

  if (!incomingRefreshToken) {
    throw new ApiError(401, "Unauthorized Request");
  }

  try {
    const decodedToken = jwt.verify(
      incomingRefreshToken,
      process.env.REFRESH_TOKEN_SECRET
    );

    const user = await User.findById(decodedToken?._id);

    if (!user) {
      throw new ApiError(401, "Invalid refresh token");
    }

    if (user?.refreshToken !== incomingRefreshToken) {
      throw new ApiError(401, "Refresh token is expired or used");
    }

    const options = {
      httpOnly: true,
      secure: true,
    };

    const { accessToken, newRefreshToken } =
      await generateAccessAndRefreshTokens(user._id);

    return res
      .status(200)
      .cookie("accessToken", accessToken, options)
      .cookie("refreshToken", newRefreshToken, options)
      .json(
        new ApiResponse(
          200,
          { accessToken, refreshToken: newRefreshToken },
          "Token refreshed successfully"
        )
      );
  } catch (error) {
    throw new ApiError(401, error?.message || "Invalid refresh token");
  }
});

const changeCurrentPassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user?._id);
  const isPasswordCorrect = await user.isPasswordCorrect(currentPassword);

  if (!isPasswordCorrect) {
    throw new ApiError(401, "Invalid current password");
  }

  user.password = newPassword;
  await user.save({ validateBeforeSave: false });

  return res.status(200).json(new ApiResponse(200, {}, "Password updated"));
});

const getCurrentUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user?._id).select(
    "-password -refreshToken"
  );

  if (!user) {
    throw new ApiError(404, "User not found");
  }

  return res.status(200).json(new ApiResponse(200, user, "User found"));
});

const updateAccountDetails = asyncHandler(async (req, res) => {
  const { fullName, email } = req.body;

  if (!fullName || !email) {
    throw new ApiError(400, "All fields are required");
  }

  const user = User.findByIdAndUpdate(
    req.user?._id,
    {
      $set: {
        fullName,
        email,
      },
    },
    { new: true }
  ).select("-password");

  return res
    .status(200)
    .json(new ApiResponse(200, user, "Account details updated successfully"));
});

const updateUserAvatar = asyncHandler(async (req, res) => {
  const avatarLocalPath = req.files?.avatar[0]?.path;

  if (!avatarLocalPath) {
    throw new ApiError(400, "avatar file is missing");
  }

  const avatar = await uploadOnCloudinary(avatarLocalPath);

  if (!avatar.url) {
    throw new ApiError(400, "Error while uploading avatar");
  }

  const user = await User.findByIdAndUpdate(
    req.user?._id,
    {
      $set: {
        avatar: avatar.url,
      },
    },
    { new: true }
  ).select("-password");

  fetchCurrentUser();

  return res.status(200).json(new ApiResponse(200, user, "Avatar updated"));
});

const getUserProfile = asyncHandler(async (req, res) => {
  const { username } = req.params;

  if (!username?.trim()) {
    throw new ApiError(400, "Username is missing");
  }

  const profile = await User.aggregate([
    {
      $match: {
        username: username?.toLowerCase(),
      },
    },
  ]);
});

const checkAuth = asyncHandler(async (req, res) => {
  console.log("req.user", req.user);
  try {
    const user = await User.findById(req.user?._id).select("-password");
    return res
      .status(200)
      .json(new ApiResponse(200, user, "User is Authenticated"));
  } catch (error) {
    return res.status(401).json(new ApiResponse(401, {}, "Unauthorized"));
  }
});

const addToCart = asyncHandler(async (req, res) => {
  try {
    const { productId } = req.body;
    const userId = req.user._id; // assuming that the user ID is stored in req.user._id

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Check if the product is already in the cart
    const productIndex = user.cart.findIndex(
      (item) => item.product.toString() === productId
    );
    if (productIndex !== -1) {
      // If the product is already in the cart, update its quantity
      user.cart[productIndex].quantity += 1;
    } else {
      // If the product is not in the cart, add it to the cart
      user.cart.push({ product: productId, quantity: 1 });
    }

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "Product added to cart successfully",
      cart: user.cart,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getCartItems = asyncHandler(async (req, res) => {
  try {
    const userId = req.user._id; // assuming that the user ID is stored in req.user._id

    // Find the user by ID and populate the cart with the product details
    const user = await User.findById(userId).populate("cart.product");
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Respond with the cart items
    res.status(200).json({
      message: "Cart items retrieved successfully",
      cart: user.cart,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const removeFromCart = asyncHandler(async (req, res) => {
  try {
    const { productId } = req.body;
    const userId = req.user._id;

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Find the index of the product in the cart
    const productIndex = user.cart.findIndex(
      (cartItem) => cartItem.product.toString() === productId
    );

    if (productIndex === -1) {
      throw new ApiError(404, "Product not found in cart");
    }

    // Remove the product from the cart
    user.cart.splice(productIndex, 1);

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "Product removed from cart successfully",
      cart: user.cart,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const removeAllFromCart = asyncHandler(async (req, res) => {
  try {
    const userId = req.user._id;

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Clear the cart by setting it to an empty array
    user.cart = [];

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "All products removed from cart successfully",
      cart: user.cart,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const updateCartItemQuantity = asyncHandler(async (req, res) => {
  try {
    const { productId, newQuantity } = req.body;
    const userId = req.user._id;

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Find the product in the cart
    const productInCart = user.cart.find(
      (cartItem) => cartItem.product.toString() === productId
    );

    if (!productInCart) {
      throw new ApiError(404, "Product not found in cart");
    }

    // Update the product's quantity
    productInCart.quantity = newQuantity;

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "Product quantity updated successfully",
      cart: user.cart,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const addToWishlist = asyncHandler(async (req, res) => {
  try {
    const { productId } = req.body;
    const userId = req.user._id;

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Check if the product is already in the wishlist
    const productInWishlist = user.wishlist.find(
      (wishlistItem) => wishlistItem.product.toString() === productId
    );

    if (productInWishlist) {
      throw new ApiError(400, "Product already in wishlist");
    }

    // Add the product to the wishlist
    user.wishlist.push({ product: productId });

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "Product added to wishlist successfully",
      wishlist: user.wishlist,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const removeFromWishlist = asyncHandler(async (req, res) => {
  try {
    const { productId } = req.body;
    const userId = req.user._id;

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Find the index of the product in the wishlist
    const productIndex = user.wishlist.findIndex(
      (wishlistItem) => wishlistItem.product.toString() === productId
    );

    if (productIndex === -1) {
      throw new ApiError(404, "Product not found in wishlist");
    }

    // Remove the product from the wishlist
    user.wishlist.splice(productIndex, 1);

    // Save the updated user to the database
    await user.save();

    // Respond with success message
    res.status(200).json({
      message: "Product removed from wishlist successfully",
      wishlist: user.wishlist,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getWishlist = asyncHandler(async (req, res) => {
  try {
    const userId = req.user._id;

    // Find the user by ID and populate the wishlist products
    const user = await User.findById(userId).populate("wishlist.product");
    if (!user) {
      throw new ApiError(404, "User not found");
    }

    // Respond with the wishlist items
    res.status(200).json({
      message: "Wishlist retrieved successfully",
      wishlist: user.wishlist,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const getAllUsers = asyncHandler(async (req, res) => {
  try {
    // Fetch all users from the database
    const users = await User.find();

    // If no users found, return an error
    if (!users || users.length === 0) {
      throw new ApiError(404, "No users found");
    }

    // Respond with the list of users
    res.status(200).json({
      message: "All users",
      users,
    });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(error.statusCode || 500).json({
      message: error.message || "Internal server error",
    });
  }
});

const updateFullName = asyncHandler(async (req, res) => {
  const { fullName } = req.body;

  if (!fullName) {
    throw new ApiError(400, "Full name is required");
  }

  const user = await User.findById(req.user._id);

  if (!user) {
    throw new ApiError(404, "User not found");
  }

  user.fullName = fullName;
  await user.save();

  return res
    .status(200)
    .json(
      new ApiResponse(
        200,
        { fullName: user.fullName },
        "Full name updated successfully"
      )
    );
});

export {
  registerUser,
  loginUser,
  logoutUser,
  refreshAccessToken,
  changeCurrentPassword,
  getCurrentUser,
  updateAccountDetails,
  updateUserAvatar,
  getUserProfile,
  checkAuth,
  addToCart,
  getCartItems,
  removeFromCart,
  updateCartItemQuantity,
  addToWishlist,
  removeFromWishlist,
  getAllUsers,
  removeAllFromCart,
  updateFullName,
  getWishlist,
};
