export const DB_NAME = "Shopease";
